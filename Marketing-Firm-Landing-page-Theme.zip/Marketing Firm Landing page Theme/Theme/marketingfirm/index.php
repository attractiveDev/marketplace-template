<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @package marketingfirm
 */

get_header();
?>
<div class="container">
    <div class="row">
        <div id="primary" class="content-area col-lg-8 col-xl-9">
            <main id="main" class="site-main">
                <?php
                    if ( have_posts() )
                    {
                        while ( have_posts() )
                        {
                            the_post();
                            get_template_part( 'template-parts/loop', get_post_type() );
                        }
                        travelagency_posts_navigation();
                    }
                    else
                    {
                        get_template_part( 'template-parts/content', 'none' );
                    }
                ?>
            </main>
        </div>
        <aside id="secondary" class="widget-area col-lg-4 col-xl-3">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</div>
<?php
get_footer();
