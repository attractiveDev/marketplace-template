<?php
/**
 * The template for displaying archive pages
 *
 * @package marketingfirm
 */

get_header();
?>
<div class="container">
    <div class="row">
        <div id="primary" class="content-area col-lg-8 col-xl-9">
            <main id="main" class="site-main">
                <?php
                    if ( have_posts() )
                    {
                        while ( have_posts() )
                        {
                            the_post();
                            get_template_part( 'template-parts/loop', get_post_type() );
                        }
                        travelagency_posts_navigation();
                    }
                    else
                    {
                        get_template_part( 'template-parts/content', 'none' );
                    }
                ?>
            </main>
        </div>
        <aside id="secondary" class="widget-area col-lg-4 col-xl-3">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</div>
<?php
get_footer();
