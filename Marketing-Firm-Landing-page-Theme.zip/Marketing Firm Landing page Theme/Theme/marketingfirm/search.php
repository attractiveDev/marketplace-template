<?php
/**
 * The template for displaying search results pages
 *
 * @package marketingfirm
 */

get_header();
?>
<div class="container">
    <div class="row">
        <section id="primary" class="content-area col-lg-8 col-xl-9">
            <main id="main" class="site-main">
                <?php
                    if ( have_posts() )
                    {
                        while ( have_posts() )
                        {
                            the_post();
                            get_template_part( 'template-parts/loop-search' );
                        }
                        travelagency_posts_navigation();
                    }
                    else
                    {
                        echo '<div class="search-results-none">';
                        printf(
                            '<h2 class="title">%s</h2>',
                            esc_html__( 'Nothing\'s found', 'marketingfirm' )
                        );
                        printf(
                            '<p class="desc">%s</p>',
                            esc_html__( 'There is no results with your search query, maybe try another keywords.', 'marketingfirm' )
                        );
                        get_search_form();
                        echo '</div>';
                    }
                ?>
            </main>
        </section>
        <aside id="secondary" class="widget-area col-lg-4 col-xl-3">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</div>
<?php
get_footer();
