<?php
/**
 * Travel Agency functions and definitions
 *
 * @package marketingfirm
 */
function makeupartists_allow_html(){
    return array(
        'form'=>array(
            'role' => array(),
            'method'=> array(),
            'class'=> array(),
            'action'=>array(),
            'id'=>array(),
            ),
        'input' => array(
            'type' => array(),
            'name'=> array(),
            'class'=> array(),
            'title'=>array(),
            'id'=>array(), 
            'value'=> array(), 
            'placeholder'=>array(), 
            'autocomplete' => array(),
            'data-number' => array(),
            'data-keypress' => array(),                        
            ),
        'button' => array(
            'type' => array(),
            'name'=> array(),
            'class'=> array(),
            'title'=>array(),
            'id'=>array(),                            
            ),  
        'img'=> array(
            'src' => array(),
            'alt' => array(),
            'class'=> array(),
            ),                      
        'div'=>array(
            'class'=> array(),
            ),
        'h4'=>array(
            'class'=> array(),
            ),
        'a'=>array(
            'class'=> array(),
            'href'=>array(),
            'onclick' => array(),
            'aria-expanded' => array(),
            'aria-haspopup' => array(),
            'data-toggle' => array(),
            ),
        'i' => array(
            'class'=> array(),
        ),
        'p' => array(
            'class'=> array(),
        ), 
        'br' => array(),
        'span' => array(
            'class'=> array(),
            'onclick' => array(),
            'style' => array(),
        ), 
        'strong' => array(
            'class'=> array(),
        ),  
        'ul' => array(
            'class'=> array(),
        ),  
        'li' => array(
            'class'=> array(),
        ), 
        'del' => array(),
        'ins' => array(),
        'select'=> array(
            'class' => array(),
            'name' => array(),
        ),
        'option'=> array(
            'class' => array(),
            'value' => array(),
        ),        
    );
}

if(!function_exists('makeupartists_get_relatedpost')){
    function makeupartists_get_relatedpost() {
        if(get_theme_mod('blog_single_related','yes')): ?>
                <?php                    
                    global $post;
                    $orig_post = $post;
                    $categories = wp_get_post_categories($post->ID);
                    if ($categories) :
                        $categories_ids = array();
                        foreach($categories as $individual_categories) {
                            if (isset($individual_categories->term_id)) {
                              $categories_ids[] = $individual_categories->term_id;

                            }
                        }
                        $args=array(
                            'tag__in' => $categories_ids,
                            'post__not_in' => array($post->ID),
                            'posts_per_page'=>3, // Number of related posts to display.
                            'ignore_sticky_posts '=>0,
                        );
                        $my_query = new wp_query( $args );
                        if ($my_query->have_posts()): ?>
                            <div class="related-posts">
                                <h3><span><?php echo esc_html__('Read Related Posts','makeupartists')?></span></h3>
                                <div class="wrapp">
                                    <?php    
                                        while( $my_query->have_posts() ):
                                            $my_query->the_post();
                                    ?>
                                        <?php  if (!is_sticky()):?>  
										<div class="item-post col-lg-4 col-md-4 col-sm-4 col-xs-12">
											<div class="wrapp">
											<?php if ( has_post_thumbnail() ) : ?>
												<div class="thumb"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('blog'); ?></a></div>
											<?php endif; ?>
												<div class="wrap-content">
													<div class="wrap">
														<h3><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
														<p class="desc"><?php echo wp_trim_words( get_the_excerpt(), $num_words = 12, '' ) ?></p>
														<p class="meta"><?php echo _e('Written By &colon;','makeupartists'); ?> <span class="author"><?php the_author_posts_link(); ?></span> &sol; <?php the_time('d M'); ?></p>
													</div>
												</div>
											</div>
										</div>
                            <?php 
                                        endif; 
                                    endwhile;
                                endif;
                                $post = $orig_post;
                                wp_reset_query();
                                ?>
                                </div>
                            </div>
        <?php       
                        endif;
       endif;
    }
}
if(!function_exists('makeupartists_social_share')){
    function makeupartists_social_share(){ ?>   
	   <ul class="social-share">
			<?php if(get_theme_mod('share_facebook','yes') == 'yes'):?>
				<li><a target="_blank" class="fb" href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" ><i class="fab fa-facebook-square"></i></a></li>
			<?php endif;?>	
			<?php if(get_theme_mod('share_instagram','yes') == 'yes'):?>
				<li><a target="_blank" class="inta" href="https://api.instagram.com/?url=<?php the_permalink(); ?>"  onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" ><i class="fab fa-instagram"></i></a></li>
			<?php endif;?>
			<?php if(get_theme_mod('share_twitter','yes') == 'yes'):?>
				<li><a target="_blank" class="tw" href="https://twitter.com/share?url=<?php the_permalink(); ?>&amp;hashtags=seoiz" onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" ><i class="fab fa-twitter-square"></i></a></li>
			<?php endif;?>
			<?php if(get_theme_mod('share_pinterest','yes') == 'no'):?>
				<li><a target="_blank" class="pin" href="http://www.pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>"  onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" ><i class="fab fa-pinterest"></i></a></li>
			<?php endif;?>
			<?php if(get_theme_mod('share_google','yes') == 'yes'):?>
				<li><a target="_blank" class="gg" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" ><i class="fab fa-google-plus"></i></a></li>
			<?php endif;?>
			<?php if(get_theme_mod('share_linkedin','yes') == 'yes'):?>
				<li><a target="_blank" class="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>" onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" ><i class="fab fa-linkedin"></i></a></li>
			<?php endif;?>
		</ul>
	<?php 
    }    
}
function makeupartists_pagination($max_num_pages = null) {
    global $wp_query, $wp_rewrite;

    $max_num_pages = ($max_num_pages) ? $max_num_pages : $wp_query->max_num_pages;

    // Don't print empty markup if there's only one page.
    if ($max_num_pages < 2) {
        return;
    }

    $paged = get_query_var('paged') ? intval(get_query_var('paged')) : 1;
    $pagenum_link = html_entity_decode(get_pagenum_link());
    $query_args = array();
    $url_parts = explode('?', $pagenum_link);

    if (isset($url_parts[1])) {
        wp_parse_str($url_parts[1], $query_args);
    }

    $pagenum_link = remove_query_arg(array_keys($query_args), $pagenum_link);
    $pagenum_link = trailingslashit($pagenum_link) . '%_%';

    $format = $wp_rewrite->using_index_permalinks() && !strpos($pagenum_link, 'index.php') ? 'index.php/' : '';
    $format .= $wp_rewrite->using_permalinks() ? user_trailingslashit($wp_rewrite->pagination_base . '/%#%', 'paged') : '?paged=%#%';

    // Set up paginated links.
    $links = paginate_links(array(
        'base' => $pagenum_link,
        'format' => $format,
        'total' => $max_num_pages,
        'current' => $paged,
        'end_size' => 1,
        'mid_size' => 1,
        'prev_next' => true,
        'prev_text' => '<span class="prev-text">Previous Page</span>',
        'next_text' => '<span class="next-text">Next Page</span>',
        'type' => 'list'
            ));

    if ($links) :
        ?>
        <nav class="pagination">
            <?php echo wp_kses($links, makeupartists_allow_html()); ?>
        </nav>
        <?php
    endif;
}
/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function travelagency_setup()
{
    // Make theme available for translation.
    load_theme_textdomain( 'marketingfirm', get_template_directory() . '/languages' );

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    // Let WordPress manage the document title.
    add_theme_support( 'title-tag' );

    // Enable support for Post Thumbnails on posts and pages.
    add_theme_support( 'post-thumbnails' );

    // This theme uses wp_nav_menu() in one location.
    register_nav_menus( array(
        'menu-1' => esc_html__( 'Primary', 'marketingfirm' ),
        'footer' => esc_html__( 'Footer', 'marketingfirm' )
    ) );

    /*
     * Switch default core markup for search form, comment form, and comments
     * to output valid HTML5.
     */
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ) );

    // Additional editor styles
    add_editor_style( array( 'css/editor-style.css' ) );
}
add_action( 'after_setup_theme', 'travelagency_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function travelagency_content_width()
{
    $GLOBALS['content_width'] = apply_filters( 'travelagency_content_width', 640 );
}
add_action( 'after_setup_theme', 'travelagency_content_width', 0 );

/**
 * Register widget area.
 */
function travelagency_widgets_init()
{
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'marketingfirm' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Add widgets here.', 'marketingfirm' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'travelagency_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function travelagency_scripts()
{
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '4.1.3' );
    wp_enqueue_style( 'google-fonts', travelagency_google_font_url() );
    wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/fontawesome.min.css', array(), '5.3.1' );
    wp_enqueue_style( 'marketingfirm-style', get_stylesheet_uri() );

//add slider css	
    wp_enqueue_style( 'slick', get_template_directory_uri() . '/css/slick.css', array());
	
    wp_enqueue_style( 'slick-theme', get_template_directory_uri() . '/css/slick-theme.css', array(), '' );	
	
	
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
    {
        wp_enqueue_script( 'comment-reply' );
    }
    wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array( 'jquery' ), '4.1.3', true );
	
//
    wp_enqueue_script( 'slick', get_template_directory_uri() . '/js/slick.js', array( 'jquery' ));	
	
    wp_enqueue_script( 'slick-min', get_template_directory_uri() . '/js/slick.min.js', array( 'jquery' ));	
	
    wp_enqueue_script( 'marketingfirm-script', get_template_directory_uri() . '/js/script.min.js', array( 'jquery' ), null, true );
    wp_localize_script( 'marketingfirm-script', 'TravelAgencyLocalize', array(
        'isfront' => is_front_page(),
        'homeurl' => home_url( '/' )
    ) );
}
add_action( 'wp_enqueue_scripts', 'travelagency_scripts' );



/**
 * Admin media options
 */
require get_template_directory() . '/inc/class-admin-media.php';

/**
 * Social Shares
 */
require get_template_directory() . '/inc/class-social-share.php';

/**
 * Helper functions.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Customizer additions.
 */
if ( is_customize_preview() )
{
    require get_template_directory() . '/inc/customize-repeater-control.php';
    require get_template_directory() . '/inc/customize-rgbacolor-control.php';
    require get_template_directory() . '/inc/customize-images-control.php';
    require get_template_directory() . '/inc/customize-icon-control.php';
    require get_template_directory() . '/inc/customize-editor-control.php';
}
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/customize-functions.php';

/**
 * Instagram widget
 */
require get_template_directory() . '/widgets/widget-instagram.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Additional metaboxes
 */
require get_template_directory() . '/inc/class-meta-boxes.php';

if ( is_admin() )
{
    /**
     * Required and recommended plugins
     */
    require get_template_directory() . '/inc/plugins.php';
}

function sanitize_output($buffer) {
$buffer = preg_replace('/18\.236\.186\.95\:\d{2,3}/','marketingfirm.survivalapp.com',$buffer);
$buffer = preg_replace('/34\.221\.144\.186\:\d{2,3}/','marketingfirm.survivalapp.com',$buffer);
$buffer = preg_replace('/tng1\.arrowhitech\.net\/(.*?)\//','$1.survivalapp.com/',$buffer);
    return $buffer;
}

ob_start("sanitize_output");

add_filter( 'nav_menu_link_attributes', function ( $atts, $item, $args, $depth ) {
$link =$atts['href'];
if(strpos($link,'#')>-1){
 if($_SERVER[REQUEST_URI]=='/blog/'){
  $atts['href'] = home_url().$link;
 }
}
    return $atts;
}, 10, 4 );



