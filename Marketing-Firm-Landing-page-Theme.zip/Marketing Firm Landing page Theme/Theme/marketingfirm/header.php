<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @package marketingfirm
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700|Roboto:100,300,400,500,700,900" rel="stylesheet">
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
    <header id="masthead" class="site-header">
        <div class="container wide-container main-header-container">
            <div class="site-branding">
                <?php get_template_part( 'template-parts/branding' ); ?>
            </div>
            <?php
                $header_custom_text = get_theme_mod( 'taheader_text', esc_html__( 'Header custom text', 'marketingfirm' ) );
                if ( $header_custom_text )
                {
                    printf( '<div class="header-custom-text">%s</div>', wp_kses_post( $header_custom_text ) );
                }
            ?>
            <nav id="site-navigation" class="main-navigation" data-el="aria">
                <?php
                    if ( has_nav_menu( 'menu-1' ) )
                    {
                        wp_nav_menu( array(
                            'theme_location' => 'menu-1',
                            'menu_id'        => 'mastmenu',
                            'container'      => '',
                            'menu_class'     => 'nav primary-menu'
                        ) );
                    }
                    else
                    {
                        echo '<div class="text-center" style="line-height: 60px;">';
                        if ( is_user_logged_in() && current_user_can( 'edit_theme_options' ) )
                        {
                            printf(
                                esc_html__( 'Main menu is not set, please %s and assign to "primary" location.', 'marketingfirm' ),
                                '<a style="display:inline;" href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">' . esc_html__( 'Create Menu', 'marketingfirm' ) . '</a>'
                            );
                        }
                        else
                        {
                            printf(
                                esc_html__( 'Main menu is not set. Please %s to create menu and assign to "primary" location.', 'marketingfirm' ),
                                '<a style="display:inline;" href="' . esc_url( wp_login_url( admin_url( 'nav-menus.php' ) ) ) . '">' . esc_html__( 'Login', 'marketingfirm' ) . '</a>'
                            );
                        }
                        echo '</div>';
                    }
                ?>
            </nav>
            <nav id="site-nav-tools" class="site-nav-tools">
                <button class="menu-toggle" aria-controls="site-navigation" aria-expanded="false" data-el="aria">
                    <span class="screen-reader-text"><?php esc_html_e( 'Primary Menu', 'marketingfirm' ); ?></span>
                    <span class="menu-icon"></span>
                </button>
            </nav>
        </div>
    </header>
    <?php get_template_part( 'template-parts/page-header' ); ?>
    <div id="content" <?php travelagency_site_content_class(); ?>>
