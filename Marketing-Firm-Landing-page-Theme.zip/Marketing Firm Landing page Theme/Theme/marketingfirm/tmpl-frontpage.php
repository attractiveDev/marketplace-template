<?php
/**
 * Template name: Front Page
 * The template for displaying front page
 *
 * @package ToursTravels
 */

get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <?php
            $sections = array(
                'hero',
                'places',
                'promotion',
                'features',
                'gallery',
                'blog',
                //'cta',
				'testimonials'
            );

            if ( have_posts() )
            {
                while ( have_posts() )
                {
                    the_post();
                    foreach ( $sections as $section )
                    {
                        $template = locate_template( 'section-parts/section-' . $section . '.php' );
                        if ( $template )
                        {
                            get_template_part( 'section-parts/section', $section );
                        }
                        else
                        {
                            trigger_error(
                                sprintf(
                                    /* translators: %s section id, "%s" template parts folder name */
                                    esc_html__( 'The template file for %1$s does not exist. Please create one in %2$s.', 'marketingfirm' ),
                                    '"' . $section . '"',
                                    '"section-parts/section-' . $section . '.php"'
                                )
                            );
                        }
                    }
                }
            }
            else
            {
                get_template_part( 'template-parts/content', 'none' );
            }
        ?>
    </main>
</div>

<?php
get_footer();
