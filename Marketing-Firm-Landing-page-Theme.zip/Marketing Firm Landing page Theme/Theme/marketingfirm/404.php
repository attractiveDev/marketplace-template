<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package marketingfirm
 */

get_header();
?>
<div class="container">
    <div id="primary" class="content-area">
        <main id="main" class="site-main">

            <section class="error-404 not-found">
                <h2 class="error-404-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'marketingfirm' ); ?></h2>
                <div class="error-404-content">
                    <p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'marketingfirm' ); ?></p>

                    <?php
                        get_search_form();
                    ?>
                </div>
            </section>

        </main>
    </div>
</div>
<?php
get_footer();
