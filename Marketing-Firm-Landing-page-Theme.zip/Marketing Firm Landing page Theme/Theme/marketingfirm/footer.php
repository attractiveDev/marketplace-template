<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package marketingfirm
 */

//$img  = get_theme_mod( 'footer_img', get_template_directory_uri() . '/images/footer.jpg' );
$logo = get_theme_mod( 'footer_logo' );
$form = get_theme_mod( 'footer_newsletter_sc' );
$copy1 = get_theme_mod( 'footer-text', 'address' );
$copy = get_theme_mod( 'copyright_info', '(C) 2018. All Rights Reserved. Parker Travel Agency. Designed by Template.net' );
$text_newletter = get_theme_mod( 'footer-text_newletter', 'You can unsuscribe anytime, Please click here to unsuscribe now' );
$text_newletter1 = get_theme_mod( 'footer-text_newletter1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis t' );
//start social footer

$btn_link   = get_theme_mod( 'facebook_btn_link', '#' );

$btn_link1   = get_theme_mod( 'twitter_btn_link', '#' );

$btn_link2   = get_theme_mod( 'instagram_btn_link', '#' );

$btn_link3   = get_theme_mod( 'google_btn_link', '#' );

$btn_link4  = get_theme_mod( 'linkedin_btn_link', '#' );

$styles = array();

if ( $img )
{
    $styles[] = 'background-image:url(' . esc_url( $img ) . ')';
}
?>

    </div>

    <footer id="colophon" class="site-footer"<?php echo $styles ? ' style="' . implode( ';', array_filter( $styles ) ). '"' : ''; ?>>
        <div class="container wide-container footer-container">
			<div class="footer-1">
			<?php
				if ( $logo )
				{
					$logo_img = wp_get_attachment_image( $logo, 'full' );
					if ( $logo_img )
					{
						printf(
							'<div class="footer-logo">
								<a class="footer-logo-link" href="%1$s">%2$s</a>
							</div>',
							esc_url( home_url( '/' ) ),
							$logo_img
						); // WPCS: XSS ok.
					}
				}		
				if ( $copy1 )
				{
					printf( '<div class="site-info">%s</div>', wpautop( $copy1 ) );
				}	
			?>
			</div>
			<div class="footer-2">
			<?php				
				echo'<h2 class="title-footer">Newsletter</h2>';
				if ( $text_newletter )
				{
					printf( '<div class="site-info-1">%s</div>', wpautop( $text_newletter ) );
				}	
				if ( $form )
				{
					echo '<div class="fnewsletter-form">';
					echo do_shortcode( $form );
					echo '</div>';
				}
				if ( $text_newletter1 )
				{
					printf( '<div class="site-info-2">%s</div>', wpautop( $text_newletter1 ) );
				}					

			?>
			</div>
			<div class="footer-3">
				<?php
				echo'<h2 class="title-footer">Social Links</h2>';
				// facebook
				if ($btn_link )
				{
					echo '<div class="section-actions facebook">';
					printf(
						'<a href="%1$s" class="section-action-link"> Like us on Facebook </a>',
						esc_url( $btn_link ),
						$btn_target ? ' target="_blank"' : ' target="_self"',
						esc_html( $btn_title )
					);
					echo '</div>';
				}
				if ($btn_link1 )
				{
					echo '<div class="section-actions twitter">';
					printf(
						'<a href="%1$s" class="section-action-link"> Follow on Twitter </a>',
						esc_url( $btn_link1 ),
						$btn_target ? ' target="_blank"' : ' target="_self"',
						esc_html( $btn_title )
					);
					echo '</div>';
				}
				if ($btn_link2 )
				{
					echo '<div class="section-actions instagram">';
					printf(
						'<a href="%1$s" class=" section-action-link"> Like on Instagram</a>',
						esc_url( $btn_link2 ),
						$btn_target ? ' target="_blank"' : ' target="_self"',
						esc_html( $btn_title )
					);
					echo '</div>';
				}
				if ($btn_link3 )
				{
					echo '<div class="section-actions google">';
					printf(
						'<a href="%1$s" class="section-action-link"> Follow on Google Plus </a>',
						esc_url( $btn_link3 ),
						$btn_target ? ' target="_blank"' : ' target="_self"',
						esc_html( $btn_title )
					);
					echo '</div>';
				}
				if ($btn_link4 )
				{
					echo '<div class="section-actions linkedin">';
					printf(
						'<a href="%1$s" class=" section-action-link"> Joind us on Linkedin </a>',
						esc_url( $btn_link4 ),
						$btn_target ? ' target="_blank"' : ' target="_self"',
						esc_html( $btn_title )
					);
					echo '</div>';
				}
				
				?>
		
			</div>
        </div>
		<div class="footer-copy-right">
			<?php
				if ( $copy )
				{
					printf( '<div class="site-info-footer">%s</div>', wpautop( $copy ) );
				}		
			?>
		</div>
    </footer>
    <a href="javascript:void(0)" class="back-to-top" data-eltype="totopbtn">
        <span class="screen-reader-text"><?php esc_html_e( 'Back to top', 'travelagency' ); ?></span>
        <i class="fa fa-angle-up"></i>
    </a>	
	
</div>

<?php wp_footer(); ?>

</body>
</html>
