<?php
/**
 * Template name: Right Sidebar
 *
 * @package marketingfirm
 */

get_header();
?>
<div class="container">
    <div class="row">
        <div id="primary" class="content-area col-lg-8 col-xl-9">
            <main id="main" class="site-main">
                <?php
                    while ( have_posts() )
                    {
                        the_post();
                        get_template_part( 'template-parts/content', 'page' );

                        if ( comments_open() || get_comments_number() )
                        {
                            comments_template();
                        }
                    }
                ?>
            </main>
        </div>
        <aside id="secondary" class="widget-area col-lg-4 col-xl-3">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</div>
<?php
get_footer();
