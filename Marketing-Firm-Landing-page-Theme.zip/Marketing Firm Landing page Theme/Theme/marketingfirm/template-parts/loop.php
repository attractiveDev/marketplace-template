<?php
/**
 * Template part for displaying posts in loops
 *
 * @package marketingfirm
 */
?>
<article <?php post_class( 'loop-hentry' ); ?>>
    <?php if ( has_post_thumbnail() ) : ?>
    <div class="entry-thumbnail">
        <a class="entry-thumbnail-link" href="<?php the_permalink(); ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
            <?php the_post_thumbnail( 'medium' ); ?>
        </a>
    </div>
    <?php endif; ?>
    <div class="entry-body">
        <header class="entry-header">
            <?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
            <div class="entry-meta">
                <?php
                    travelagency_entry_sticky();
                    travelagency_posted_by();
                    travelagency_comments_count();
                ?>
            </div>
        </header>
        <div class="entry-summary">
            <?php travelagency_entry_excerpt( 32 ); ?>
        </div>
    </div>
</article>