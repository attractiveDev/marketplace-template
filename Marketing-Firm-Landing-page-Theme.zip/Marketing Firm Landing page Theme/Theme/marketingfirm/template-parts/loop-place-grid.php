<?php
/**
 * Template part for displaying posts in loops
 *
 * @package marketingfirm
 */
?>
<article <?php post_class( 'loop-place-grid-hentry' ); ?>>
    <?php if ( has_post_thumbnail() ) : ?>
    <div class="entry-thumbnail">
        <a class="entry-thumbnail-link" href="<?php the_permalink(); ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
            <?php the_post_thumbnail( 'medium' ); ?>
        </a>
    </div>
    <?php endif; ?>
    <div class="entry-body">
        <header class="entry-header">
            <?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
        </header>
        <div class="entry-summary"><?php echo travelagency_entry_excerpt( 18 ); ?></div>
        <footer class="entry-footer">
            <?php
                $categories = wp_get_post_terms( get_the_ID(), 'category' );
                $opts = maybe_unserialize( get_post_meta( get_the_ID(), '_ta_place_options', true ) );
                $opts = wp_parse_args( $opts, array(
                    'price' => ''
                ) );

                if ( $categories || $opts['price'] )
                {
                    echo '<div class="entry-price">';
                    echo    '<span class="cat-names">';
                    foreach ( $categories as $cat )
                    {
                        echo '<span class="cat-name">' . esc_html( $cat->name ) . '</span>';
                    }
                    echo    '</span>';
                    echo    '<span class="tour-price">';
                    echo        esc_html( $opts['price'] );
                    echo    '</span>';
                    echo '</div>';
                }

                printf( 
                    '<div class="entry-read-more"><a class="read-more-link" href="%1$s">%2$s</a></div>',
                    esc_url( get_permalink() ),
                    esc_html__( 'Read More', 'marketingfirm' )
                );
            ?>
        </footer>
    </div>
</article>