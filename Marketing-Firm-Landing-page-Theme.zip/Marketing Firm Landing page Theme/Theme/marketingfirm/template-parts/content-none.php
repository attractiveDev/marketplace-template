<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @package hostel
 */

?>

<section class="no-results not-found" style="text-align: center;">
    <h2><?php esc_html_e( 'Nothing Found', 'hostel' ); ?></h2>
    <div class="page-content">
        <p><?php esc_html_e( 'Something went wrong or nothing found at this location.', 'hostel' ); ?></p>
    </div>
</section>
