	<div class="item-post">
		<div class="wrapp">
		<?php if ( has_post_thumbnail() ) : ?>
			<div class="col-md-7 col-sm-7 col-xs-12 left-content">
				<div class="wrap">
					<div class="thumb"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><span class="wrap-img"  style="background-image:url(<?php echo the_post_thumbnail_url(); ?>);"><?php the_post_thumbnail('blog'); ?></span></a></div>
					<div class="author-share">
						<?php
							if(function_exists('makeupartists_social_share')){
							   makeupartists_social_share();
							}
						?>
						<div class="author"><span><?php _e('Author :', 'makeupartists'); ?></span> <?php the_author_posts_link(); ?></div>				
					</div>
				</div>
			</div>
		<?php endif; ?>
			<div class="right-content col-md-5 col-sm-5 col-xs-12">
				<div class="wrap">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
					<div class="meta"><span class="date"><?php echo get_the_date('F j Y'); ?></span><span class="comment"><?php echo '&lpar;'.get_comments_number().'&rpar;'; _e(' Comments','makeupartists');?></span></div>
					<p class="desc"><?php echo wp_trim_words( get_the_excerpt(), $num_words = 40, '' ) ?></p>
					<a class="read-more" href="<?php echo get_permalink(); ?>" title=""><?php echo _e('Continue Reading','makeupartists'); ?></a>
				</div>
			</div>
		</div>
	</div>