<?php
/**
 * Template part for displaying posts in search
 *
 * @package marketingfirm
 */
?>
<article <?php post_class( 'loop-search' ); ?>>
    <div class="entry-body">
        <header class="entry-header">
            <?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
            <p class="entry-permalink">
                <a href="<?php the_permalink(); ?>"><?php the_permalink(); ?></a>
            </p>
        </header>
        <div class="entry-summary">
            <?php travelagency_entry_excerpt( 32 ); ?>
        </div>
    </div>
</article>