<?php
/**
 * Show logo and/or site title/description
 * @package ToursTravels
 */
$description = get_bloginfo( 'description', 'display' );
$hide_text   = 'blank' == get_theme_mod( 'header_textcolor', '' );

the_custom_logo();

if ( is_front_page() && is_home() )
{
    printf(
        '<h1 class="site-title%1$s"><a href="%2$s" rel="home">%3$s</a></h1>',
        $hide_text ? ' screen-reader-text' : '',
        esc_url( home_url( '/' ) ),
        get_bloginfo( 'name', 'display' )
    );
}
else
{
    printf(
        '<p class="site-title%1$s"><a href="%2$s" rel="home">%3$s</a></p>',
        $hide_text ? ' screen-reader-text' : '',
        esc_url( home_url( '/' ) ),
        get_bloginfo( 'name', 'display' )
    );
}

if ( $description || is_customize_preview() )
{
    printf(
        '<p class="site-description%1$s">%2$s</p>',
        $hide_text ? ' screen-reader-text' : '',
        $description
    ); // WPCS: xss ok
}
