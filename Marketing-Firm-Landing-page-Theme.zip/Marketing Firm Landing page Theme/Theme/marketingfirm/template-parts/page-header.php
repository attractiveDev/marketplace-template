<?php
/**
 * Template part for displaying page title. Apply only for archives
 *
 * @package marketingfirm
 */
if ( is_front_page() )
{
    return;
}

$img_url = get_header_image();
$titles  = travelagency_get_page_titles();
$styles  = array();
if ( $img_url )
{
    $styles[] = 'background-image:url(' . esc_url( $img_url ) . ')';
}
?>
<div id="pagehead" class="site-pheader"<?php echo ( ! empty( $styles ) ? ' style="' . esc_attr( implode( ';', $styles ) ) . '"' : '' ); ?>>
    <div class="container pheader-content">
        <div class="pheader-box">
            <div class="pheader-box-inner">
                <?php
                    if ( ! empty( $titles['title'] ) )
                    {
                        printf( '<h1 class="title"><span>%s</span></h1>', $titles['title'] );
                    }
                    if ( ! empty( $titles['subtitle'] ) )
                    {
                        printf( '<div class="desc">%s</div>', wpautop( $titles['subtitle'] ) );
                    }
                ?>
            </div>
        </div>
    </div>
</div>
