<?php

/**
 * Alpha Color Picker Customizer Control
 *
 * This control adds a second slider for opacity to the stock WordPress color picker,
 * and it includes logic to seamlessly convert between RGBa and Hex color values as
 * opacity is added to or removed from a color.
 *
 * @package marketingfirm
 */
class TravelAgency_Customize_RGBAColor_Control extends WP_Customize_Control
{
    /**
     * Give the control a name.
     */
    public $type = 's_rgbacolor';

    /**
     * Add support for custom_palettes to be passed in.
     *
     * Palette values are true, false, or an array of RGBa and Hex colors.
     */
    public $custom_palettes = array();

    /**
     * Constructor
     * 
     * @param WP_Customize_Manager $manager Customizer bootstrap instance.
     * @param string               $id      Control ID.
     * @param array                $args
     */
    public function __construct( $manager, $id, $args = array() )
    {
        parent::__construct( $manager, $id, $args );

        //$args['custom_palettes'] = isset( $args['custom_palettes'] ) ? $args['custom_palettes'] : true;

        if ( is_array( $this->custom_palettes ) )
        {
            $this->custom_palettes = array_filter( $this->custom_palettes, 'travelagency_is_valid_color' );
            $this->custom_palettes = implode( '|', $this->custom_palettes );

            if ( empty( $this->custom_palettes ) )
            {
                $this->custom_palettes = true;
            }
        }
        else
        {
            $this->custom_palettes = ( false === $this->custom_palettes || 'false' === $this->custom_palettes ) ? false : true;
        }
    }

    public function enqueue()
    {
        // wp_enqueue_script( 'customize-srgbacolor-control', get_template_directory_uri() . '/js/rgbacolor-control.js', array(), '1.0', true );
    }

    /**
     * Must be empty to override parent class. We use content_template instead
     */
    public function render_content() {}

    /**
     * Render a JS template for the content of the control.
     */
    public function content_template()
    {
        ?>
        <label>
            <#
            if ( data.label ) {
                #><span class="customize-control-title">{{{ data.label }}}</span><#
            }
            if ( data.description ) {
                #><span class="description customize-control-description">{{{ data.description }}}</span><#
            }
            #>
            <input type="text" value="{{ data.value }}" class="rgba-color-field" data-custom-palettes="{{ data.customPalettes }}" data-default-color="{{ data.defaultValue }}" {{{ data.settingLink }}}/>
        </label>
        <?php
    }

    /**
     * Refresh the parameters passed to the JavaScript via JSON.
     */
    public function to_json()
    {
        parent::to_json();

        $this->json['value']          = $this->value();
        $this->json['defaultValue']   = $this->setting->default;
        $this->json['customPalettes'] = $this->custom_palettes;
        $this->json['settingLink']    = $this->get_link();
    }
}