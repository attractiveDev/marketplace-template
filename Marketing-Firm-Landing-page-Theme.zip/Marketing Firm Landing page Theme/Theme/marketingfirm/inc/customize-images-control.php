<?php

/**
 * Multiple images picker control class
 *
 * @since 1.0.0
 */
class TravelAgency_Customize_Images_Control extends WP_Customize_Control
{
    /**
     * The type of customize control being rendered.
     *
     * @since  1.0.0
     * @access public
     * @var    string
     */
    public $type = "s_images";

    /**
     * Allow options to be parsed in.
     *
     * @since 1.0
     * @access protected
     * @var integer
     */
    public $options = array();

    /**
     * Constructor
     * 
     * @param WP_Customize_Manager $manager Customizer bootstrap instance.
     * @param string               $id      Control ID.
     * @param array                $args
     */
    public function __construct( $manager, $id, $args = array() )
    {
        parent::__construct( $manager, $id, $args );

        $this->options = wp_parse_args( $this->options, array(
            'frame_label'         => esc_html__( 'Select Media', 'marketingfirm' ),
            'button_label'        => esc_html__( 'Select Media', 'marketingfirm' ),
            'button_remove_label' => esc_html__( 'Remove', 'marketingfirm' ),
            'button_edit_label'   => esc_html__( 'Edit', 'marketingfirm' ),
            'empty_msg'           => esc_html__( 'No Media selected', 'marketingfirm' ),
            'max_items'           => 0,
            'multiple'            => false,
            'media_types'         => 'image'
        ) );

        $media_types = is_string( $this->options['media_types'] ) ? explode( ',', $this->options['media_types'] ) : array( 'image' );
        $media_types = array_map( 'trim', $media_types );

        foreach ( $media_types as $key => $type )
        {
            if ( ! in_array( $type, array( 'image', 'video' ) ) )
            {
                unset( $media_types[ $key ] );
            }
        }

        if ( empty( $media_types ) )
        {
            $media_types = 'image';
        }
        else
        {
            $media_types = implode( ',', $media_types );
        }

        $this->options['media_types'] = $media_types;
    }

    public function enqueue()
    {
        //wp_enqueue_script( 'customize-images-control', get_template_directory_uri() . '/js/images-control.js', array( 'media-upload' ), '1.0', true );
    }

    /**
     * Must be empty to override parent class. We use content_template instead
     */
    public function render_content() {}

    /**
     * Render a JS template for the content of the control.
     */
    public function content_template()
    {
        ?>
        <label>
            <#
            if ( data.label ) {
                #><span class="customize-control-title">{{{ data.label }}}</span><#
            }
            if ( data.description ) {
                #><span class="description customize-control-description">{{{ data.description }}}</span><#
            }
            #>
        </label>
        <input type="hidden" value="{{ data.value }}" class="images-field" data-field-type="s_images" {{{ data.settingLink }}} />
        <?php
    }

    public function filter_values( $v )
    {
        $number = absint( $v );

        if ( $number <= 0 )
        {
            return false;
        }
        
        return true;
    }

    /**
     * Refresh the parameters passed to the JavaScript via JSON.
     */
    public function to_json()
    {
        parent::to_json();

        $value = $this->value();

        if ( ! is_array( $value ) )
        {
            $value = explode( ',', $value );
        }

        $value = array_filter( $value, array( $this, 'filter_values' ) );

        if ( empty( $value ) )
        {
            $value = array();
        }

        $value = implode( ',', $value );

        $this->json['value'] = $value;
        $this->json['settingLink'] = $this->get_link();
        $this->json['options']['frameLabel']        = $this->options['frame_label'];
        $this->json['options']['buttonLabel']       = $this->options['button_label'];
        $this->json['options']['buttonRemoveLabel'] = $this->options['button_remove_label'];
        $this->json['options']['buttonEditLabel']   = $this->options['button_edit_label'];
        $this->json['options']['emptyMsg']          = $this->options['empty_msg'];
        $this->json['options']['maxItems']          = $this->options['max_items'];
        $this->json['options']['multiple']          = $this->options['multiple'];
        $this->json['options']['mediaTypes']        = $this->options['media_types'];
    }
}