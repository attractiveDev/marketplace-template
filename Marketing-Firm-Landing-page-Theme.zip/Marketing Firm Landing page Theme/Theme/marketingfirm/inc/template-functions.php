<?php
/**
 * Helper functions for the theme
 *
 * @package marketingfirm
 */

/**
 * Generate local font css url.
 * This function can be overrided by child theme.
 * 
 * @return string
 */
function travelagency_local_font_url()
{
    return get_template_directory_uri() . '/css/fonts.min.css';
}

/**
 * Generate google font url.
 * This function can be overrided by child theme.
 * 
 * @return string
 */
function travelagency_google_font_url()
{
    $fonts_url = '';
    $fonts     = array();
    $subsets   = 'latin,latin-ext';

    /* translators: If there are characters in your language that are not supported by Nunito, translate this to 'off'. Do not translate into your own language. */
    if ( 'off' !== _x( 'on', 'Nunito font: on or off', 'marketingfirm' ) )
    {
        $fonts[] = 'Nunito:400,400i,600,700';
    }

    /* translators: If there are characters in your language that are not supported by Montserrat, translate this to 'off'. Do not translate into your own language. */
    if ( 'off' !== _x( 'on', 'Montserrat font: on or off', 'marketingfirm' ) )
    {
        $fonts[] = 'Montserrat:300,400,600,400i';
    }

    if ( $fonts )
    {
        $fonts_url = add_query_arg( array(
            'family' => urlencode( implode( '|', $fonts ) ),
            'subset' => urlencode( $subsets ),
        ), 'https://fonts.googleapis.com/css' );
    }

    return $fonts_url;
}


/**
 * Create formated attributes for html tag from array
 * 
 * @param  array  $atts Array of attributes where array key is attribute name.
 * @return string Properly formated and escaped attributes. Empty string on failue
 */
function travelagency_get_html_atts( $atts = array() )
{
    if ( ! is_array( $atts ) || empty( $atts ) )
    {
        return '';
    }

    $atts = wp_parse_args( $atts, array(
        'id' => '',
        'class' => array(),
        'style' => array()
    ) );

    $allowed_attributes = array(
        'accesskey',
        'class',
        'contenteditable',
        'contextmenu',
        'dir',
        'draggable',
        'dropzone',
        'hidden',
        'id',
        'lang',
        'spellcheck',
        'style',
        'tabindex',
        'title',
        'translate'
    );

    if ( is_array( $atts['class'] ) && ! empty( $atts['class'] ) )
    {
        $atts['class'] = implode( ' ', $atts['class'] );
    }
    else
    {
        unset( $atts['class'] );
    }
    if ( is_array( $atts['style'] ) && ! empty( $atts['style'] ) )
    {
        $atts['style'] = implode( ';', $atts['style'] );
    }
    else
    {
        unset( $atts['style'] );
    }

    $atts = array_filter(
        $atts,
        function( $value, $key ) use ( $allowed_attributes )
        {
            if ( empty( $value ) || ! is_string( $key ) || strpos( $key, ' ' ) !== false )
            {
                return false;
            }
            if ( ! in_array( $key, $allowed_attributes, true ) )
            {
                if ( 0 !== strpos( $key, 'data-' ) )
                {
                    return false;
                }

                $data_attr_name = substr( $key, 5 );
                if ( ! preg_match( '/[a-z]+[A-Za-z0-9-_]*/', $data_attr_name ) )
                {
                    return false;
                }
            }

            return true;
        },
        ARRAY_FILTER_USE_BOTH
    );

    return implode( ' ', array_map(
        function( $value, $key )
        {
            return $key . '="' . esc_attr( $value ) . '"';
        },
        $atts,
        array_keys( $atts )
    ) );
}

/**
 * Get titles of current view
 * @return array  Array keys contain 'title', 'subtitle'
 */
function travelagency_get_page_titles()
{
    $title = $subtitle = '';
    $page_for_posts = get_option( 'page_for_posts' );
    $default_title = $page_for_posts ? get_the_title( $page_for_posts ) : esc_html__( 'Blog', 'marketingfirm' );

    if ( is_archive() )
    {
        $subtitle = get_the_archive_description();
        if ( is_category() )
        {
            $title = single_cat_title( '', false );
        }
        elseif ( is_tag() )
        {
            $title = single_tag_title( '', false );
        }
        elseif ( is_day() )
        {
            $title = get_the_date();
        }
        elseif ( is_month() )
        {
            $title = get_the_date( 'F Y' );
        }
        elseif ( is_year() )
        {
            $title = get_the_date( 'Y' );
        }
        elseif ( is_author() )
        {
            $title = '<span class="vcard">' . get_the_author() . '</span>';
        }
    }
    else
    {
        if ( is_page() )
        {
            $title = get_the_title();
        }
        elseif ( is_404() )
        {
            $title = esc_html__( '404', 'marketingfirm' );
        }
        elseif ( is_search() )
        {
            $title = esc_html__( 'Search Results', 'marketingfirm' );
            
            $subtitle = sprintf(
                /* translators: "%s" current search keywords */
                esc_html__( 'You searched for: "%s"', 'marketingfirm' ),
                get_search_query()
            );
        }
        elseif ( is_single() )
        {
            $queried_object = get_queried_object();
            $post_type_object = null;

            if ( $queried_object )
            {
                $post_type_object = get_post_type_object( $queried_object->post_type );
            }
            
            if ( $post_type_object && 'post' != $post_type_object->name )
            {
                $title = $post_type_object->labels->singular_name;
            }
            else
            {
                $title = $default_title;
            }
        }
        else
        {
            $title = $default_title;
        }
    }

    return array(
        'title' => $title,
        'subtitle' => $subtitle
    );
}


/**
 * Global kses parameter for wp_kses.
 * Each allowed tags can only contains id, style and class.
 * Except for anchor tag which can contains href, and rel.
 * 
 * @param  string $type 'inline' for all inline tags,
 *                      'inlinep' for all inline tags include p tag.
 *                      'link' for all inline tags those allowed to put inside a tag.
 *                      For all others, please use wp_kses_post
 *                       
 * @return array
 */
function travelagency_global_kses( $type = 'inline' )
{
    $result = array();

    switch ( $type )
    {
        case 'inlinep':
            $result = array(
                'p' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'span' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'strong' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'em' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'q' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'a' => array( 'href' => array(), 'rel' => array(), 'style' => array(), 'class' => array(), 'id' => array() ),
                'i' => array( 'style' => array(), 'class' => array(), 'id' => array() )
            );
            break;

        case 'inline':
            $result = array(
                'cite' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'span' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'strong' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'em' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'q' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'a' => array( 'href' => array(), 'rel' => array(), 'style' => array(), 'class' => array(), 'id' => array() ),
                'i' => array( 'style' => array(), 'class' => array(), 'id' => array() )
            );
            break;

        case 'link':
            $result = array(
                'span' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'strong' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'em' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'q' => array( 'style' => array(), 'class' => array(), 'id' => array() ),
                'i' => array( 'style' => array(), 'class' => array(), 'id' => array() )
            );
            break;

        default:
            break;
    }

    return $result;
}

/**
 * Generates an excerpt from the post content with custom length. Default length is 55 words.
 *
 * The excerpt word amount will be 55 words and if the amount is greater than
 * that, then the string '&hellip;' will be appended to the excerpt. If the string
 * is less than 55 words, then the content will be returned as is.
 *
 * @param int $length Optional. Custom excerpt length, default to 55.
 * @param int|WP_Post $post Optional. You will need to provide post id or post object if used outside loops.
 * @return string The excerpt with custom length.
 */
function travelagency_get_the_excerpt( $length = 55, $post = null )
{
    $post = get_post( $post );

    if ( empty( $post ) || 0 >= $length )
    {
        return '';
    }

    if ( post_password_required( $post ) )
    {
        return esc_html__( 'Post password required.', 'marketingfirm' );
    }

    $content = apply_filters( 'the_content', strip_shortcodes( $post->post_content ) );
    $content = str_replace( ']]>', ']]&gt;', $content );

    $excerpt_more = apply_filters( 'travelagency_excerpt_more', '&hellip;' );
    $excerpt = wp_trim_words( $content, $length, $excerpt_more );

    return $excerpt;
}


/**
 * Check if string is valid css id or class
 * @param  string $string
 * @param  string $default If the css id or class is invalid, then we will use default value for that
 * @return boolean
 */
function travelagency_is_valid_css_id_class( $string )
{
    $string = trim( $string );
    if ( preg_match( '/^[a-zA-Z]+[a-zA-Z0-9_-]*$/', $string, $matches ) )
    {
        $string = $matches[0];
    }
    else
    {
        $string = '';
    }

    if ( strlen( $string ) == 0 )
    {
        return false;
    }

    return true;
}


/**
 * Check if color string is valid hex/rgba
 * 
 * @param  string  $color_string
 * @return boolean 
 */
function travelagency_is_valid_color( $color_string )
{
    if ( ! is_string( $color_string ) )
    {
        return false;
    }

    $color_string = preg_replace( "/\s+/m", '', $color_string );

    if ( $color_string === 'transparent' )
    {
        return true;
    }

    if ( '' == $color_string ) return false;

    if ( preg_match( "/(?:^#[a-fA-F0-9]{6}$)|(?:^#[a-fA-F0-9]{3}$)/", $color_string ) ) return true;

    if ( preg_match( "/(?:^rgba\(\d+\,\d+\,\d+\,(?:\d*(?:\.\d+)?)\)$)|(?:^rgb\(\d+\,\d+\,\d+\)$)/", $color_string ) )
    {
        preg_match_all( "/\d+\.*\d*/", $color_string, $matches );
        if ( empty( $matches ) || empty( $matches[0] ) ) return false;

        $red = empty( $matches[0][0] ) ? $matches[0][0] : 0;
        $green = empty( $matches[0][1] ) ? $matches[0][1] : 0;
        $blue = empty( $matches[0][2] ) ? $matches[0][2] : 0;
        $alpha = empty( $matches[0][3] ) ? $matches[0][3] : 1;

        if ( $red < 0 || $red > 255 || $green < 0 || $green > 255 || $blue < 0 || $blue > 255 || $alpha < 0 || $alpha > 1.0 ) return false;
    }
    else
    {
        return false;
    }

    return true;
}

/**
 * Generate unique id with specific length
 *
 * @param  integer $length Default to 6
 * @return string
 */
function travelagency_generate_uiqueid( $length = 6 )
{
    return substr( md5( microtime() ), rand( 0, 26 ), $length );
}


/**
 * This function minify css
 * 
 * @param  string $css
 * @return string
 */
function travelagency_css_minifier( $css )
{
    // Normalize whitespace
    $css = preg_replace( '/\s+/', ' ', $css );
    // Remove spaces before and after comment
    $css = preg_replace( '/(\s+)(\/\*(.*?)\*\/)(\s+)/', '$2', $css );
    // Remove comment blocks, everything between /* and */, unless
    // preserved with /*! ... */ or /** ... */
    $css = preg_replace( '~/\*(?![\!|\*])(.*?)\*/~', '', $css );
    // Remove ; before }
    $css = preg_replace( '/;(?=\s*})/', '', $css );
    // Remove space after , : ; { } */ >
    $css = preg_replace( '/(,|:|;|\{|}|\*\/|>) /', '$1', $css );
    // Remove space before , ; { } ( ) >
    $css = preg_replace( '/ (,|;|\{|}|\(|\)|>)/', '$1', $css );
    // Strips leading 0 on decimal values (converts 0.5px into .5px)
    $css = preg_replace( '/(:| )0\.([0-9]+)(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}.${2}${3}', $css );
    // Strips units if value is 0 (converts 0px to 0)
    $css = preg_replace( '/(:| )(\.?)0(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}0', $css );
    // Converts all zeros value into short-hand
    $css = preg_replace( '/0 0 0 0/', '0', $css );
    // Shortern 6-character hex color codes to 3-character where possible
    $css = preg_replace( '/#([a-f0-9])\\1([a-f0-9])\\2([a-f0-9])\\3/i', '#\1\2\3', $css );
    return trim( $css );
}

/**
 * Custom callback function for wp_list_comments
 *
 * @since  1.0
 * @param  object $comment
 * @param  array  $args
 * @param  int    $depth
 * @return void
 */
function travelagency_comment_template( $comment, $args, $depth )
{
    $GLOBALS['comment'] = $comment;
    $comment_date_format = apply_filters( 'travelagency_comment_date_format', 'j F Y \a\t g:i a' );
    extract( $args, EXTR_SKIP );

    if ( 'div' == $args['style'] )
    {
        $tag = 'div';
        $add_below = 'comment';
    }
    else
    {
        $tag = 'li';
        $add_below = 'div-comment';
    }

    echo '<' . esc_attr( $tag ) . ' ';
    comment_class( empty( $args['has_children'] ) ? '' : 'parent' );
    echo ' id="comment-';
    comment_ID();
    echo '">';

    $avatar = get_avatar( $comment, 140 );
    
    if ( 'div' != $args['style'] )
    {
        // Open -->
        printf(
            '<div id="div-comment-%1$s" class="comment-body %2$s">',
            esc_attr( get_comment_ID() ),
            $avatar ? '' : 'no-avatar'
        );
    }
    printf( '<div class="comment-author-image vcard">%s</div>', $avatar );
    ?>
    <div class="comment-main">
        <div class="comment-header">
            <h5 class="comment-author"><?php echo get_comment_author_link(); ?></h5>
            <?php comment_reply_link( array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
        </div>
        <div class="comment-date"><?php echo get_comment_date( $comment_date_format, get_comment_ID() ); ?></div>
        <?php if ( $comment->comment_approved == '0' ) : ?>
        <p class="comment-awaiting-moderation"><em><?php esc_html_e( 'Your comment is awaiting moderation.' , 'marketingfirm' ); ?></em></p>
        <?php endif; ?>
        <div class="comment-content">
            <?php comment_text(); ?>
        </div>
    </div>
    <?php
    if ( 'div' != $args['style'] )
    {
        // <-- Close
        echo '</div>';
    }
}

/**
 * Display navigation to next/previous comments when applicable.
 * @return void
 */
function travelagency_comments_navigation()
{
    // Do nothing if there's nothing to navigate
    if ( get_comment_pages_count() <= 1 || ! get_option( 'page_comments' ) )
    {
        return;
    }
    ?>
    <nav class="navigation comment-navigation" role="navigation">
        <h2 class="screen-reader-text"><?php esc_html_e( 'Comment navigation', 'marketingfirm' ); ?></h2>
        <div class="nav-links">
            <?php
                if ( $prev_link = get_previous_comments_link( esc_html__( 'Older Comments', 'marketingfirm' ) ) )
                {
                    printf( '<div class="nav-previous">%s</div>', $prev_link );
                }

                if ( $next_link = get_next_comments_link( esc_html__( 'Newer Comments', 'marketingfirm' ) ) )
                {
                    printf( '<div class="nav-next">%s</div>', $next_link );
                }
            ?>
        </div><!-- .nav-links -->
    </nav><!-- .comment-navigation -->
    <?php
}