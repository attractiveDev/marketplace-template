<?php
/**
 * Editor customize control class
 *
 * @since 1.0.0
 */
class TravelAgency_Customize_Editor_Control extends WP_Customize_Control
{
    /**
     * The type of customize control being rendered.
     *
     * @since  1.0.0
     * @access public
     * @var    string
     */
    public $type = "s_editor";

    /**
     * Constructor
     * 
     * @param WP_Customize_Manager $manager Customizer bootstrap instance.
     * @param string               $id      Control ID.
     * @param array                $args
     */
    public function __construct( $manager, $id, $args = array() )
    {
        parent::__construct( $manager, $id, $args );
        add_action( 'customize_controls_print_footer_scripts', array( __CLASS__, 'item_tpl' ), 66 );
    }

    /**
     * Enqueue script and styles for the control
     */
    public function enqueue()
    {
        // wp_enqueue_script( 'customize-editor-control', get_template_directory_uri() . '/js/editor-control.js', array(), '1.0', true );
        // wp_enqueue_editor();
    }


    /**
     * Must be empty to override parent class. We use content_template instead
     */
    public function render_content() {}

    /**
     * Render a JS template for the content of the control.
     */
    public function content_template()
    {
        ?>
        <label>
            <#
            if ( data.label ) {
                #><span class="customize-control-title">{{{ data.label }}}</span><#
            }
            if ( data.description ) {
                #><span class="description customize-control-description">{{{ data.description }}}</span><#
            }
            #>
        </label>

        <textarea aria-hidden="true" class="editor-field" data-field-type="s_editor" {{{ data.settingLink }}} style="display: none;">{{{ data.value }}}</textarea>
        <?php
    }

    /**
     * Refresh the parameters passed to the JavaScript via JSON.
     */
    public function to_json()
    {
        parent::to_json();

        $this->json['value'] = $this->value();
        $this->json['settingLink'] = $this->get_link();
    }

    /**
     * Render the control's template.
     */
    public static function item_tpl()
    {
        ?>
        <script type="text/html" id="tmpl__s_mce_preloaded_editor">
            <?php wp_editor( '', '__s_mce_preloaded_editor' ); ?>
        </script>
        <?php
    }
}