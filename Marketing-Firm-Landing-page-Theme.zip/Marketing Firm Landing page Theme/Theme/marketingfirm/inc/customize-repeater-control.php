<?php
/**
 * Repeatable control class.
 *
 * @since  1.0.0
 */

class TravelAgency_Customize_Misc_Control extends WP_Customize_Control
{
    /**
     * The type of customize control being rendered.
     *
     * @since  1.0.0
     * @access public
     * @var    string
     */
    public $type = 's_misc';

    /**
     * Display type for the control, accept 'all', 'heading', 'desc'
     *
     * @since  1.0.0
     * @access public
     * @var    string
     */
    public $display = 'all';

    /**
     * Show divider or not
     *
     * @since  1.0.0
     * @access public
     * @var    boolean
     */
    public $divider = false;

    /**
     * Constructor
     * 
     * @param WP_Customize_Manager $manager Customizer bootstrap instance.
     * @param string               $id      Control ID.
     * @param array                $args
     */
    public function __construct( $manager, $id, $args = array() )
    {
        parent::__construct( $manager, $id, $args );

        if ( 'all' != $this->display && 'heading' != $this->display && 'desc' != $this->display )
        {
            $this->display = 'all';
        }

        $this->divider = ( 'true' == $this->divider || $this->divider ) ? true : false;
    }

    /**
     * Must be empty to override parent class. We use content_template instead
     */
    public function render_content() {}

    /**
     * Render a JS template for the content of the control.
     */
    public function content_template()
    {
        ?>
        <# if ( data.label || data.description ) { #>
        <div class="s_misc-control">
            <# if ( data.label && ( 'all' == data.display || 'heading' == data.display ) ) { #>
                <span class="customize-control-title">{{{ data.label }}}</span>
            <# } #>
            <# if ( data.description && ( 'all' == data.display || 'desc' == data.display ) ) { #>
                <span class="description customize-control-description">{{{ data.description }}}</span>
            <# } #>
        </div class="s_misc-control">
        <# } #>
        <# if ( data.divider ) { #><hr/><# } #>
        <?php
    }

    /**
     * Refresh the parameters passed to the JavaScript via JSON.
     */
    public function to_json()
    {
        parent::to_json();

        $this->json['display'] = $this->display;
        $this->json['divider'] = $this->divider;
    }
}

class TravelAgency_Customize_Repeater_Control extends WP_Customize_Control
{
    /**
     * The type of customize control being rendered.
     *
     * @since  1.0.0
     * @access public
     * @var    string
     */
    public $type = 's_repeater';

    /**
     * Parameter fields for the control
     *
     * @since 1.0
     * @access public
     * @var   array
     */
    public $fields = array();

    /**
     * Maximum items allowed
     *
     * @since 1.0
     * @access public
     * @var integer
     */
    public $max_items = 0;

    /**
     * Sortable items
     *
     * @since 1.0
     * @access public
     * @var boolean
     */
    public $sortable = true;

    /**
     * Default item title
     *
     * @since 1.0
     * @access public
     * @var string
     */
    public $item_title;

    /**
     * Field for live item title update
     *
     * @since 1.0
     * @access public
     * @var boolean
     */
    public $item_title_field = false;

    /**
     * Add item button text
     * @since 1.0
     * @access public
     * @var string
     */
    public $new_item_button_text = '';

    /**
     * Default values when adding new item
     *
     * @since 1.0
     * @access public
     * @var boolean
     */
    public $new_item_values = array();

    /**
     * Constructor
     * 
     * @param WP_Customize_Manager $manager Customizer bootstrap instance.
     * @param string               $id      Control ID.
     * @param array                $args
     */
    public function __construct( $manager, $id, $args = array() )
    {
        parent::__construct( $manager, $id, $args );

        if ( ! isset( $this->fields ) || ! is_array( $this->fields ) || empty( $this->fields ) )
        {
            $this->fields = array();
        }

        foreach ( $this->fields as $field_id => $field )
        {
            if ( ! isset( $field['type'] ) )
            {
                $field['type'] = 'text';
            }

            switch ( $field['type'] )
            {
                case 'rgbacolor':
                    if ( isset( $field['custom_palettes'] ) )
                    {
                        if ( is_array( $field['custom_palettes'] ) )
                        {
                            $field['custom_palettes'] = array_filter( $field['custom_palettes'], 'travelagency_is_valid_color' );
                            $field['custom_palettes'] = implode( '|', $field['custom_palettes'] );

                            if ( ! $field['custom_palettes'] )
                            {
                                $field['custom_palettes'] = true;
                            }
                        }
                        else
                        {
                            $field['custom_palettes'] = ( false === $field['custom_palettes'] || 'false' === $field['custom_palettes'] ) ? false : true;
                        }
                    }
                    else
                    {
                        $field['custom_palettes'] = true;
                    }
                    break;

                case 'images':
                    $field['options'] = isset( $field['options'] ) ? (array) $field['options'] : array();

                    $field['options'] = wp_parse_args( $field['options'], array(
                        'frame_label'         => esc_html__( 'Select Media', 'marketingfirm' ),
                        'button_label'        => esc_html__( 'Select Media', 'marketingfirm' ),
                        'button_remove_label' => esc_html__( 'Remove', 'marketingfirm' ),
                        'button_edit_label'   => esc_html__( 'Edit', 'marketingfirm' ),
                        'empty_msg'           => esc_html__( 'No Media selected', 'marketingfirm' ),
                        'max_items'           => 0,
                        'multiple'            => false,
                        'media_types'          => 'image'
                    ) );

                    $media_types = is_string( $field['options']['media_types'] ) ? explode( ',', $field['options']['media_types'] ) : array( 'image' );
                    $media_types = array_map( 'trim', $media_types );

                    foreach ( $media_types as $key => $type )
                    {
                        if ( ! in_array( $type, array( 'image', 'video' ) ) )
                        {
                            unset( $media_types[ $key ] );
                        }
                    }

                    if ( empty( $media_types ) )
                    {
                        $media_types = 'image';
                    }
                    else
                    {
                        $media_types = implode( ',', $media_types );
                    }

                    $images_options = array(
                        'frameLabel'        => $field['options']['frame_label'],
                        'buttonLabel'       => $field['options']['button_label'],
                        'buttonRemoveLabel' => $field['options']['button_remove_label'],
                        'buttonEditLabel'   => $field['options']['button_edit_label'],
                        'emptyMsg'          => $field['options']['empty_msg'],
                        'maxItems'          => $field['options']['max_items'],
                        'multiple'          => $field['options']['multiple'],
                        'mediaTypes'        => $media_types
                    );
                    
                    $field['options'] = $images_options;
                    break;

                case 'icon':
                    $field['options'] = isset( $field['options'] ) ? (array) $field['options'] : array();

                    $field['options'] = wp_parse_args( $field['options'], array(
                        'button_label'        => esc_html__( 'Select', 'marketingfirm' ),
                        'button_remove_label' => esc_html__( 'Remove', 'marketingfirm' )
                    ) );

                    $icon_options = array(
                        'buttonLabel'       => $field['options']['button_label'],
                        'buttonRemoveLabel' => $field['options']['button_remove_label']
                    );
                    
                    $field['options'] = $icon_options;

                default:
                    break;
            }

            if ( ! isset( $field['hide_on_unremovable'] ) )
            {
                $field['hideOnUnremovable'] = false;
            }
            else
            {
                $field['hideOnUnremovable'] = (bool) $field['hide_on_unremovable'];
                unset( $field['hide_on_unremovable'] );
            }

            if ( ! isset( $field['only_on_unremovable'] ) )
            {
                $field['onlyOnUnremovable'] = false;
            }
            else
            {
                $field['onlyOnUnremovable'] = (bool) $field['only_on_unremovable'];
                unset( $field['only_on_unremovable'] );
            }

            $this->fields[ $field_id ] = $field;
        }

        if ( isset( $this->max_items ) )
        {
            $this->max_items = (int) $this->max_items;

            if ( $this->max_items < 0 )
            {
                $this->max_items = 0;
            }
        }

        if ( ! $this->item_title )
        {
            $this->item_title = esc_html__( 'Item', 'marketingfirm' );
        }

        if ( ! $this->item_title_field || ! array_key_exists( $this->item_title_field, $this->fields ) )
        {
            $this->item_title_field = '';
        }

        $this->sortable = (bool) $this->sortable;

        if ( ! is_string( $this->new_item_button_text ) || ! strlen( $this->new_item_button_text ) )
        {
            $this->new_item_button_text = esc_html__( 'Add new Item', 'marketingfirm' );
        }
        if ( $this->new_item_values )
        {
            $this->new_item_values = (array) $this->new_item_values;
        }

        add_action( 'customize_controls_print_footer_scripts', array( __CLASS__, 'item_tpl' ), 66 );
    }

    /**
     * Get default value
     * @return mixed
     */
    public function get_default()
    {
        $setting = $this->manager->get_setting( $this->id );

        if ( $setting )
        {
            return $setting->default;
        }

        return null;
    }

    /**
     * Get fields and their args
     * @return array
     */
    public function get_fields()
    {
        return $this->fields;
    }

    /**
     * Refresh the parameters passed to the JavaScript via JSON.
     */
    public function to_json()
    {
        parent::to_json();

        $values = $this->value();
        $default = $this->get_default();

        if ( is_string( $values ) )
        {
            $decoded_value = json_decode( $values, true );

            if ( is_array( $decoded_value ) && json_last_error() == JSON_ERROR_NONE )
            {
                $values = $decoded_value;
            }
        }

        $this->json['settingLink'] = $this->get_link();

        $this->json['id']              = $this->id;
        $this->json['values']          = $values;
        $this->json['fields']          = $this->fields;
        $this->json['sortable']        = $this->sortable;
        $this->json['maxItems']        = $this->max_items;
        $this->json['itemTitle']       = $this->item_title;
        $this->json['itemTitleField']  = $this->item_title_field;
        $this->json['newItemButtonText'] = $this->new_item_button_text;
        $this->json['newItemValues']   = $this->new_item_values;
    }

    /**
     * Enqueue scripts/styles.
     *
     * @since  1.0.0
     * @access public
     * @return void
     */
    public function enqueue()
    {
        // wp_enqueue_script( 'customize-srepeater-control', get_template_directory_uri() . '/js/repeater-control.js', array(), '1.0', true );
    }

    /**
     * Item template
     */
    public static function item_tpl()
    {
        ?>
        <script type="text/html" id="tmpl-s_repeater">
            <?php self::js_item(); ?>
        </script>
        <script type="text/html" id="tmpl-add-s_repeater">
            <?php self::js_item_add(); ?>
        </script>
        <?php
    }

    /**
     * Must be empty to override parent class. We use content_template instead
     */
    public function render_content() {}

    /**
     * Render a JS template for the content of the control.
     */
    public function content_template()
    {
        ?>
        <label>
            <# if ( data.label ) { #>
                <span class="customize-control-title">{{{ data.label }}}</span>
            <# } #>

            <# if ( data.description ) { #>
                <span class="description customize-control-description">{{{ data.description }}}</span>
            <# } #>
        </label>
        <input type="hidden" {{{ data.settingLink }}} data-field-type="s_repeater"/>
        <div class="form-data">
            <ul class="items<# if ( data.sortable ) { #> sortable<# } else { #> unsortable<# } #>" data-role="items"></ul>
        </div>
        <?php
    }

    /**
     * Render the control's action content.
     */
    public static function js_item_add()
    {
        ?>
        <div class="actions" data-role="actions">
            <button class="button-secondary add-item" data-role="item-add">{{ data.newItemButtonText }}</button>
        </div>
        <?php
    }

    /**
     * Render the control's template.
     */
    public static function js_item()
    {
        ?>
        <# var itemClass = data.unremovable ? 'unremovable' : 'removable'; #>
        <li class="item {{ itemClass }}" data-role="item">
            <div class="widget">
                <div class="widget-top" data-role="item-toggler">
                    <div class="widget-title-action">
                        <button type="button" class="widget-action" aria-expanded="false">
                            <span class="screen-reader-text"><?php esc_html_e( 'Edit Item', 'marketingfirm' ); ?></span>
                            <span class="toggle-indicator" aria-hidden="true"></span>
                        </button>
                    </div>
                    <div class="widget-title">
                        <h3 data-role="item-title">{{ data.title }}</h3>
                    </div>
                </div>

                <div class="widget-inside" data-role="item-content">
                    <div class="form" data-role="form">
                        <div class="widget-content">
                            <#
                            var fs = data.fields;

                            for ( k in fs )
                            {
                                var f = fs[k];
                                #>
                                <div class="field field-type-{{ f.type }} field-{{ k }}"
                                <# if ( f.hideOnUnremovable ) { #> data-hide-on-unremovable="true"
                                <# } else if ( f.onlyOnUnremovable ) { #> data-only-on-unremovable="true"<# } #>
                                <# if ( data.titleField == k ) { #> data-title-field="true"<# } #> data-role="fieldwrap">
                                    <# if ( f.type != 'checkbox' ) { #>
                                        <# if ( f.label ) { #>
                                            <div class="customize-control-title">{{ f.label }}</div>
                                        <# } #>
                                        <# if ( f.desc ) { #>
                                            <p class="description customize-control-description">{{ f.desc }}</p>
                                        <# } #>
                                    <# } #>
                                    <# if ( f.type == 'text' || f.type == 'email' || f.type == 'url' || f.type == 'password' || f.type == 'search' || f.type == 'number' || f.type == 'tel' ) { #>
                                        <input type="{{ f.type }}" class="widefat {{ f.type }}-field" value="{{ f.value }}" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" />
                                    <# } else if ( f.type == 'radio' ) { #>
                                        <# if ( f.options ) { #>
                                            <# for ( o in f.options ) { #>
                                            <label>
                                                <input type="radio" class="{{ f.type }}-field" <# if ( f.value == o ) { #> checked="checked" <# } #> value="{{ o }}" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" />
                                                <span>{{ f.options[o] }}</span>
                                            </label>
                                            <# } #>
                                        <# } #>
                                    <# } else if ( f.type == 'checkbox' ) { #>
                                        <label>
                                            <input class="checkbox {{ f.type }}-field" type="checkbox" value="1"<# if ( f.value ) { #> checked="checked" <# } #>data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" />
                                            <# if ( f.label ) { #>
                                                <span>{{ f.label }}</span>
                                            <# } #>
                                            <# if ( f.desc ) { #>
                                                <span class="description customize-control-description">{{ f.desc }}</span>
                                            <# } #>
                                        </label>
                                    <# } else if ( f.type == 'select' ) { #>
                                            <# if ( f.multiple ) { #>
                                            <select class="widefat {{ f.type }}-field" multiple="multiple" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}">
                                            <# } else  { #>
                                            <select class="widefat {{ f.type }}-field" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}">
                                            <# } #>
                                                <# for ( o in f.options ) { #>
                                                    <# if ( _.isArray( f.value ) ) { #>
                                                        <option <# if ( _.contains( f.value , o ) ) { #> selected="selected" <# } #>  value="{{ o }}">{{ f.options[o] }}</option>
                                                    <# } else { #>
                                                        <option <# if ( f.value == o ) { #> selected="selected" <# } #>  value="{{ o }}">{{ f.options[o] }}</option>
                                                    <# } #>
                                                <# } #>
                                            </select>
                                    <# } else if ( f.type == 'icon' ) { #>
                                        <input type="hidden" value="{{ f.value }}" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" />
                                    <# } else if ( f.type == 'images' ) { #>
                                        <input type="hidden" value="{{ f.value }}" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" />
                                    <# } else if ( f.type == 'rgbacolor' ) { #>
                                        <input type="text" class="rgba-color-field" value="{{ f.value }}" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}"
                                            <# if ( f.custom_palettes ) { #> data-custom-palettes="{{ f.custom_palettes }}"<# } #> />
                                    <# } else if ( f.type == 'textarea' ) { #>
                                        <textarea class="widefat {{ f.type }}-field" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" rows="{{ f.rows }}">{{{ f.value }}}</textarea>
                                    <# } else if ( f.type == 'editor' ) { #>
                                        <textarea aria-hidden="true" class="{{ f.type }}-field" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" style="display: none;">{{{ f.value }}}</textarea>
                                    <# } else if ( f.type == 'hidden' ) { #>
                                        <input type="hidden" value="{{ f.value }}" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" />
                                    <# } else if ( f.type == 'autogen' ) { #>
                                        <# if ( f.hidden ) { #><input type="hidden"<# } else { #><input type="text"<# } #>
                                        class="widefat" value="{{ f.value }}" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" />
                                    <# } else if ( f.type == 'unremovable' ) { #>
                                        <input type="hidden" value="{{ f.value }}" data-role="field" data-field-id="{{ k }}" data-field-type="{{ f.type }}" />
                                    <# } #>
                                </div><#
                            } #>
                            <div class="widget-control-actions">
                                <hr/>
                                <div class="alignleft">
                                    <# if ( ! data.unremovable ) { #>
                                    <button type="button" class="button-link button-link-delete widget-control-remove" data-role="item-remove">Delete</button> |
                                    <# } #>
                                    <button type="button" class="button-link widget-control-close" data-role="item-close">Close</button>
                                </div>
                                <br class="clear">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
        <?php
    }
}