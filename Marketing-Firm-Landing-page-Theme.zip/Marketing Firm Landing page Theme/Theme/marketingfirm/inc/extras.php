<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package marketingfirm
 */

/**
 * Custom admin menus
 */
function travelagency_admin_menu()
{
    global $submenu;

    /**
     * @see wp-admin/menu.php
     */
    $customize_url = $submenu['themes.php'][6][2];
    unset( $submenu[ 'themes.php' ][ 6 ] );

    // Add sub menu page to the Dashboard menu.
    add_dashboard_page(
        esc_html__( 'marketingfirm Theme Customizer','marketingfirm' ),
        esc_html__( 'marketingfirm Theme Customizer','marketingfirm' ),
        'customize',
        esc_url( $customize_url ),
        ''
    );
}
add_action( 'admin_menu', 'travelagency_admin_menu', 999 );

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function travelagency_body_classes( $classes )
{
    // Adds a class of hfeed to non-singular pages.
    if ( ! is_singular() )
    {
        $classes[] = 'hfeed';
    }

    // Adds a class of no-sidebar when there is no sidebar present.
    if ( ! is_active_sidebar( 'sidebar-1' ) )
    {
        $classes[] = 'no-sidebar';
    }

    return $classes;
}
add_filter( 'body_class', 'travelagency_body_classes' );


/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function travelagency_pingback_header()
{
    if ( is_singular() && pings_open() )
    {
        echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
    }
}
add_action( 'wp_head', 'travelagency_pingback_header' );

/**
 * Default cropping for images
 */
function travelagency_after_switch_theme()
{
    if ( get_theme_mod( '_first_active', false ) )
    {
        return;
    }
    else
    {
        set_theme_mod( '_first_active', '1' );
        update_option( 'thumbnail_size_w', 140 );
        update_option( 'thumbnail_size_h', 140 );
        update_option( 'thumbnail_crop', 1 );
        update_option( 'medium_size_w', 480 );
        update_option( 'medium_size_h', 300 );
        update_option( 'medium_crop', 1 );
        update_option( 'large_size_w', 1280 ); 
        update_option( 'large_size_h', 800 );
        update_option( 'large_crop', 1 );
    }
}
add_action( 'after_switch_theme', 'travelagency_after_switch_theme' );