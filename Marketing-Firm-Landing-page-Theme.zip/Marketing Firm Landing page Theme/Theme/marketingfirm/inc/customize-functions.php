<?php
/**
 * Helper function for theme customizer
 *
 * @package marketingfirm
 */

/*--------------------------------------------------------------
# SANITIZE CALLBACKS
--------------------------------------------------------------*/

/**
 * Sanitize textfield to ouput valid css id
 * 
 * @param  string $input
 * @param  object $setting
 * @return string
 */
function travelagency_sanitize_section_id( $input, $setting )
{
    if ( preg_match( '/[a-zA-Z]+[a-zA-Z0-9_-]*/', $input, $matches ) )
    {
        return $matches[0];
    }

    return $setting->default;
}


/**
 * Sanitize the section title
 * @param  string $input
 * @param  object $setting
 * @return string
 */
function travelagency_sanitize_section_title( $input, $setting )
{
    $result = wp_kses( $input, travelagency_global_kses( 'inline' ) );
    if ( is_string( $result ) )
    {
        return $result;
    }
    return $setting->default;
}


/**
 * Sanitize textfield to ouput valid youtube video url
 * 
 * @param  string $url
 * @param  object $setting
 * @return string
 */
function travelagency_sanitize_youtube_url( $url, $setting )
{
    if ( preg_match( '#^https?://(?:www\.)?(?:youtube\.com/watch|youtu\.be/)#', $url ) )
    {
        return $url;
    }

    return $setting->default;
}


/**
 * Sanitization callback for single select and radio.
 *
 * @param  mixed  $input
 * @param  object $setting
 * @return mixed
 */
function travelagency_sanitize_choice( $input, $setting )
{
    global $wp_customize;
 
    $control = $wp_customize->get_control( $setting->id );
 
    if ( array_key_exists( $input, $control->choices ) )
    {
        return $input;
    }
    return $setting->default;
}


/**
 * Sanitization callback for multiple choices on select field
 * 
 * @param  mixed  $input
 * @param  onject $settings
 * @return mixed
 */
function travelagency_sanitize_multiple_choices( $input, $settings )
{
    global $wp_customize;
 
    $control = $wp_customize->get_control( $settings->id );
    $input = is_array( $input ) ? $input : array();
    
    foreach ( $input as $key => $value )
    {
        if ( ! array_key_exists( $value, $control->choices ) )
        {
            return $settings->default;
        }
    }

    return $input;
}

/**
 * Sanitization callback for multiple images
 * 
 * @param  mixed  $input
 * @param  onject $settings
 * @return mixed
 */
function travelagency_sanitize_ids( $input, $settings )
{
    $ids = explode( ',', $input );

    $ids = array_filter( array_map( 'absint', $ids ) );
    return implode( ',', $ids );
}


/**
 * Sanitization callback for color.
 *
 * @param  string $value color value.
 * @param  object $settings
 * @return string
 */
function travelagency_sanitize_color( $value, $settings )
{
    $color_string = preg_replace( "/\s+/m", '', $value );

    if ( $color_string === 'transparent' )
    {
        return $value;
    }

    if ( '' == $color_string )
    {
        return '';
    }

    if ( preg_match( "/(?:^#[a-fA-F0-9]{6}$)|(?:^#[a-fA-F0-9]{3}$)/", $color_string ) )
    {
        return $value;
    }

    if ( preg_match( "/(?:^rgba\(\d+\,\d+\,\d+\,(?:\d*(?:\.\d+)?)\)$)|(?:^rgb\(\d+\,\d+\,\d+\)$)/", $color_string ) )
    {
        preg_match_all( "/\d+\.*\d*/", $color_string, $matches );

        if ( empty( $matches ) || empty( $matches[0] ) )
        {
            return $settings->default;
        }

        $red = empty( $matches[0][0] ) ? $matches[0][0] : 0;
        $green = empty( $matches[0][1] ) ? $matches[0][1] : 0;
        $blue = empty( $matches[0][2] ) ? $matches[0][2] : 0;
        $alpha = empty( $matches[0][3] ) ? $matches[0][3] : 1;

        if ( $red < 0 || $red > 255 || $green < 0 || $green > 255 || $blue < 0 || $blue > 255 || $alpha < 0 || $alpha > 1.0 )
        {
            return $settings->default;
        }
    }
    else
    {
        return $settings->default;
    }

    return $value;
}


/**
 * Sanitization callback for color schemes.
 *
 * @param  string $value Color scheme name value.
 * @return string Color scheme name.
 */
function travelagency_sanitize_color_scheme( $value )
{
    $color_schemes = travelagency_get_color_scheme_choices();

    if ( ! array_key_exists( $value, $color_schemes ) )
    {
        $value = 'default';
    }

    return $value;
}


/**
 * Sanitization callback for float numbers.
 *
 * @param  string $value Maybe it is number or not.
 * @return float
 */
function travelagency_sanitize_float( $value )
{
    if ( is_numeric( $value ) )
    {
        return $value;
    }

    return 0.0;
}


/**
 * Sanitize function for repeater control
 * 
 * @param  string $input
 * @param  object $setting
 * @return array
 */
function travelagency_sanitize_repeater( $input, $setting )
{
    $control = $setting->manager->get_control( $setting->id );
    $fields  = $control->get_fields();
    $values  = array();

    ob_start();

    if ( is_string( $input ) )
    {
        $decoded_value = json_decode( wp_unslash( $input ), true );

        if ( json_last_error() == JSON_ERROR_NONE )
        {
            $values = $decoded_value;
        }
    }

    if ( ! is_array( $values ) )
    {
        $values = wp_parse_args( $values, array() );
    }

    if ( empty( $values ) )
    {
        return false;
    }

    $values = current( $values );

    foreach ( $values as $key => $item )
    {
        foreach ( $item as $i => $v )
        {
            if ( ! empty( $fields[ $i ]['sanitize_callback'] ) && is_callable( $fields[ $i ]['sanitize_callback'] ) )
            {
                $values[ $key ][ $i ] = call_user_func( $fields[ $i ]['sanitize_callback'], $values[ $key ][ $i ], $setting );
            }
            else
            {
                if ( empty( $fields[ $i ] ) || empty( $fields[ $i ][ 'type' ] ) )
                {
                    $values[ $key ][ $i ] = wp_kses_post( $v );
                }
                else
                {
                    switch ( $fields[ $i ][ 'type' ] )
                    {
                        case 'text':
                            $values[ $key ][ $i ] = wp_kses_post( $v );
                            break;
                        
                        case 'checkbox':
                        case 'unremovable':
                            $values[ $key ][ $i ] = absint( $v );
                            break;

                        case 'images':
                            $images = explode( ' ', $v );
                            $results = array();
                            foreach ( $images as $image_id )
                            {
                                $results[] = absint( $image_id );
                            }
                            $values[ $key ][ $i ] = implode( ',', array_filter( $results ) );
                            break;

                        default:
                            $values[ $key ][ $i ] = wp_kses_post( $v );
                            break;
                    }
                }
            }
        }
    }

    return $values;
}

/*--------------------------------------------------------------
# ACTIVE CALLBACKS
--------------------------------------------------------------*/

/**
 * Active callback for frontpage panels and sections
 * @return boolean
 */
function travelagency_customize_ac_frontpage()
{
    if ( ! is_page_template( 'tmpl-frontpage.php' ) )
    {
        return false;
    }
    return true;
}

/**
 * Active callback for frontpage controls
 *
 * @param  WP_Customize_Control $control
 * @return boolean
 */
function travelagency_customize_ac_frontpage_controls( $control )
{
    $res = true;
    switch ( $control->id )
    {
        case 'hero_img':
        case 'hero_id':
        case 'hero_title':
        case 'hero_desc':
            $off = (bool)$control->manager->get_setting( 'hero_off' )->value();
            if ( $off )
            {
                $res = false;
            }
            break;

        case 'places_title':
        case 'places_desc':
        case 'places_posts_num':
        case 'places_posts_col':
        case 'places_id':
            $off = (bool)$control->manager->get_setting( 'places_off' )->value();
            if ( $off )
            {
                $res = false;
            }
            break;

        case 'promotion_img':
        case 'promotion_title':
        case 'promotion_desc':
        case 'promotion_btn_title':
        case 'promotion_btn_link':
        case 'promotion_btn_target':
        case 'promotion_id':
            $off = (bool)$control->manager->get_setting( 'promotion_off' )->value();
            if ( $off )
            {
                $res = false;
            }
            break;

        case 'features_title':
        case 'features_desc':
        case 'features_btn_text':
        case 'features_id':
        case 'features_content':
            $off = (bool)$control->manager->get_setting( 'features_off' )->value();
            if ( $off )
            {
                $res = false;
            }
            break;

        case 'testimonials_title':
        case 'testimonials_desc':
        case 'testimonials_posts_num':
        case 'testimonials_posts_col':
        case 'testimonials_id':
            $off = (bool)$control->manager->get_setting( 'testimonials_off' )->value();
            if ( $off )
            {
                $res = false;
            }
            break;

        case 'blog_img':
        case 'blog_title':
        case 'blog_desc':
        case 'blog_posts_num':
        case 'blog_posts_col':
        case 'blog_id':
            $off = (bool)$control->manager->get_setting( 'blog_off' )->value();
            if ( $off )
            {
                $res = false;
            }
            break;

        case 'cta_title':
        case 'cta_desc':
        case 'cta_btn_title':
        case 'cta_btn_link':
        case 'cta_btn_target':
        case 'cta_id':
            $off = (bool)$control->manager->get_setting( 'cta_off' )->value();
            if ( $off )
            {
                $res = false;
            }
            break;

        case 'gallery_title':
        case 'gallery_desc':
        case 'gallery_insta_usr':
        case 'gallery_imgs_num':
        case 'gallery_imgs_col':
        case 'gallery_id':
            $off = (bool)$control->manager->get_setting( 'gallery_off' )->value();
            if ( $off )
            {
                $res = false;
            }
            break;

        default:
            # code...
            break;
    }
    return $res;
}

/*--------------------------------------------------------------
# PARTIALS
--------------------------------------------------------------*/

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function travelagency_customize_partial_blogname()
{
    bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function travelagency_customize_partial_blogdescription()
{
    bloginfo( 'description' );
}