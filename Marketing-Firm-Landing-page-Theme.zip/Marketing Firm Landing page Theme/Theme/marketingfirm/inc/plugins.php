<?php
/**
 * Required and recommended plugins register for the theme
 *
 * @package ToursTravels
 */
require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';

function travelagency_register_required_plugins()
{
    $plugins = array(
        array(
            'name'         => 'Custom Post Type UI',
            'slug'         => 'custom-post-type-ui',
            'required'     => false
        ),
        array(
            'name'         => 'MailChimp for WordPress',
            'slug'         => 'mailchimp-for-wp',
            'required'     => false
        )
    );

    $config = array(
        'id'           => 'marketingfirm',
        'default_path' => '',
        'menu'         => 'tgmpa-install-plugins',
        'has_notices'  => true,
        'dismissable'  => true,
        'dismiss_msg'  => '',
        'is_automatic' => false,
        'message'      => ''
    );

    tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'travelagency_register_required_plugins' );
