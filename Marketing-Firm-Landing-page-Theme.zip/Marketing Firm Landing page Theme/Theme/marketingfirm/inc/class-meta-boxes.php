<?php
/**
 * Custom metaboxes for the theme
 *
 * @package marketingfirm
 */

if ( ! is_admin() )
{
    return;
}

class TravelAgency_Meta_Boxes
{
    public $pagenow;

    function __construct()
    {
        $this->pagenow = $GLOBALS['pagenow'];

        if ( 'post.php' == $this->pagenow || 'post-new.php' == $this->pagenow )
        {
            add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
            add_action( 'save_post', array( $this, 'save_post' ) );
        }
    }

    /**
     * Add Metaboxes
     */
    function add_meta_boxes()
    {
        if ( post_type_exists( 'ta_testimonial' ) )
        {
            add_meta_box(
                '_ta_testimonial_options',
                esc_html__( 'Additional Information', 'marketingfirm' ),
                array( $this, 'ta_testimonial_meta_box' ),
                'ta_testimonial'
            );
        }

        if ( post_type_exists( 'ta_place' ) )
        {
            add_meta_box(
                '_ta_place_options',
                esc_html__( 'Additional Information', 'marketingfirm' ),
                array( $this, 'ta_place_meta_box' ),
                'ta_place'
            );
        }
    }

    /**
     * Save the metabox
     * @param  integer $post_id
     * @return void
     */
    function save_post( $post_id )
    {
        // If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
        {
            return;
        }

        if ( ! isset( $_POST['post_type'] ) || ! current_user_can( 'edit_post', $post_id ) )
        {
            return;
        }

        switch ( $_POST['post_type'] )
        {
            case 'ta_testimonial':
                $this->save_ta_testimonial( $post_id );
                break;

            case 'ta_place':
                $this->save_ta_place( $post_id );
                break;
            
            default:
                break;
        }
    }

    /**
     * Options for ta_testimonial
     * @param  WP_Post $post
     */
    function ta_testimonial_meta_box( $post )
    {
        $meta_data = maybe_unserialize( get_post_meta( $post->ID, '_ta_testimonial_options', true ) );
        $meta_data = wp_parse_args( $meta_data, array(
            'info' => ''
        ));

        wp_nonce_field( 'ta_testimonial_wpnonce_action', 'ta_testimonial_wpnonce' );
        printf( '<p><label for="ta_testimonial_info"><strong>%s</strong></label></p>', esc_html__( 'Reviewer Info', 'marketingfirm' ) );
        printf( '<input id="ta_testimonial_info" name="ta_testimonial_opts[info]" class="widefat" value="%s" />', esc_attr( $meta_data['info'] ) );
    }

    /**
     * Save the metabox for ta_testimonial post type
     * @param  integer $post_id
     * @return void
     */
    private function save_ta_testimonial( $post_id )
    {
        if ( ! isset( $_POST['ta_testimonial_wpnonce'] ) || ! wp_verify_nonce( $_POST['ta_testimonial_wpnonce'], 'ta_testimonial_wpnonce_action' ) )
        {
            return;
        }

        $meta_data = get_post_meta( $post_id, '_ta_testimonial_options', true );
        $values    = array(
            'info' => ''
        );

        if ( isset( $_POST['ta_testimonial_opts'] ) && is_array( $_POST['ta_testimonial_opts'] ) )
        {
            $loc = ! empty( $_POST['ta_testimonial_opts']['info'] ) ? esc_html( $_POST['ta_testimonial_opts']['info'] ) : '';
            $values['info'] = $loc;
        }

        update_post_meta( $post_id, '_ta_testimonial_options', maybe_serialize( $values ), $meta_data );
    }

    /**
     * Options for ta_place
     * @param  WP_Post $post
     */
    function ta_place_meta_box( $post )
    {
        $meta_data = maybe_unserialize( get_post_meta( $post->ID, '_ta_place_options', true ) );
        $meta_data = wp_parse_args( $meta_data, array(
            'price' => ''
        ));

        wp_nonce_field( 'ta_place_wpnonce_action', 'ta_place_wpnonce' );
        printf( '<p><label for="ta_place_price"><strong>%s</strong></label></p>', esc_html__( 'Price', 'marketingfirm' ) );
        printf( '<input type="text" id="ta_place_price" name="ta_place_opts[price]" class="widefat" value="%s" />', esc_attr( $meta_data['price'] ) );
    }

    /**
     * Save the metabox for ta_place post type
     * @param  integer $post_id
     * @return void
     */
    function save_ta_place( $post_id )
    {
        if ( ! isset( $_POST['ta_place_wpnonce'] ) || ! wp_verify_nonce( $_POST['ta_place_wpnonce'], 'ta_place_wpnonce_action' ) )
        {
            return;
        }

        $meta_data = get_post_meta( $post_id, '_ta_place_options', true );
        $values    = array(
            'price' => ''
        );

        if ( isset( $_POST['ta_place_opts'] ) && is_array( $_POST['ta_place_opts'] ) )
        {
            $price = ! empty( $_POST['ta_place_opts']['price'] ) ? esc_html( $_POST['ta_place_opts']['price'] ) : '';
            $values['price'] = $price;
        }

        update_post_meta( $post_id, '_ta_place_options', maybe_serialize( $values ), $meta_data );
    }
}

new TravelAgency_Meta_Boxes();