<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package marketingfirm
 */


/**
 * Print site content classes based on some conditions
 */
function travelagency_site_content_class()
{
    $class = 'site-content';

    if ( is_front_page() && ! is_home() && is_page_template( 'tmpl-frontpage.php' ) )
    {
        $class .= ' frontpage-content';
    }

    echo 'class="' . esc_attr( $class ) . '"';
}


/**
 * Prints HTML with meta information for the current post-date/time and author.
 *
 * @param  boolean $echo Echo it out or return value
 */
function travelagency_posted_on( $echo = true )
{
    ob_start();

    echo '<div class="entry-posted-on">';

    // Open the link
    printf(
        '<i class="icon far fa-clock"></i><a href="%1$s" rel="bookmark"><time class="published" datetime="%2$s"><span class="screen-reader-text">%3$s</span>%4$s</time>',
        esc_url( get_permalink() ),
        esc_attr( get_the_date( 'c' ) ),
        esc_html__( 'Published: ', 'marketingfirm' ),
        esc_html( get_the_date() )
    );

    if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) )
    {
        printf(
            '<time class="updated" datetime="%1$s"><span class="screen-reader-text">%2$s</span>%3$s</time>',
            esc_attr( get_the_modified_date( 'c' ) ),
            esc_html__( 'Updated: ', 'marketingfirm' ),
            esc_html( get_the_modified_date() )
        );
    }

    // Close the link
    echo '</a>';

    echo '</div>';

    if ( $echo )
    {
        echo ob_get_clean();
    }
    else
    {
        return ob_get_clean();
    }
}


/**
 * Entry Categories
 */
function travelagency_posted_in()
{
    /* translators: used between list items, there is a space after the comma */
    $categories_list = get_the_category_list( ', ' );

    if ( $categories_list )
    {
        printf(
            '<div class="entry-posted-in">
                <i class="icon far fa-folder"></i>
                <span class="screen-reader-text">%1$s</span>
                %2$s
            </div>',
            esc_html__( 'Posted in: ', 'marketingfirm' ),
            $categories_list
        );
    }
}

/**
 * Entry author
 */
function travelagency_posted_by()
{
    printf(
        '<div class="entry-byline"><i class="icon far fa-user"></i><span class="author vcard"><a class="url fn n" href="%2$s">%3$s</a></span></div>',
        esc_html__( 'by ', 'marketingfirm' ),
        esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
        esc_html( get_the_author() )
    );
}


/**
 * Entry comments count
 */
function travelagency_comments_count()
{
    if ( ! post_password_required() && ( comments_open() || get_comments_number() ) )
    {
        echo '<div class="entry-comments">';
        echo '<i class="icon far fa-comment"></i>';
        comments_popup_link(
            esc_html__( '(0) Comments', 'marketingfirm' ),
            esc_html__( '(1) Comment', 'marketingfirm' ), 
            esc_html__( '(%) Comments', 'marketingfirm' )
        );
        echo '</div>';
    }
}


/**
 * Custom entry excerpt
 * @param  integer $length Optional. Detaulf 55
 */
function travelagency_entry_excerpt( $length = 55, $more = false )
{
    if ( empty( $length ) )
    {
        $length = absint( get_theme_mod( 'archive_excerpt_length', 55 ) );
    }
    else
    {
        $length = absint( $length );
    }

    $length = ( 0 > $length ? 55 : $length );

    echo wpautop( travelagency_get_the_excerpt( $length ) );

    if ( $more )
    {
        printf( '<div class="entry-read-more"><a href="%1$s">%2$s</a></div>', esc_url( get_permalink() . '#' . get_the_ID() ), esc_html__( 'Read More', 'marketingfirm' ) );
    }
}


/**
 * Entry Sticky
 */
function travelagency_entry_sticky()
{
    if ( is_sticky() && ! is_paged() )
    {
        printf( '<div class="entry-sticky"><i class="icon far fa-star"></i>%s</div>', esc_html__( 'Featured', 'marketingfirm' ) );
    }
}


/**
 * Prints edit link to the current post
 * 
 * @param  boolean $echo
 * @return string
 */
function travelagency_edit_link( $echo = true )
{
    edit_post_link(
        sprintf(
            /* translators: %s: Name of current post */
            esc_html__( 'Edit %s', 'marketingfirm' ),
            the_title( '<span class="screen-reader-text">"', '"</span>', false )
        ),
        '<div class="entry-edit-link">',
        '</div>'
    );
}

/**
 * Prints posts navigation based on query
 *
 * @since  1.0
 * @param  WP_Query $query     Custom query, if left blank, this will use global query ( current query )
 * @param  string   $nav_type  Force it to output type you want. Accept 'default' and 'paged'
 * @return void
 */
function travelagency_posts_navigation( $query = null, $nav_type = '' )
{
    $classes = array();

    $nav_type = $nav_type ? $nav_type : get_theme_mod( 'posts_nav_type', 'paged' );

    if ( empty( $query ) )
    {
        $query = $GLOBALS['wp_query'];
    }

    if ( empty( $query->max_num_pages ) || ! is_numeric( $query->max_num_pages ) || $query->max_num_pages < 2 )
    {
        return;
    }

    $paged = get_query_var( 'paged' );

    if ( ! $paged && is_front_page() && ! is_home() )
    {
        $paged = get_query_var( 'page' );
    }

    $paged = $paged ? intval( $paged ) : 1;

    switch ( $nav_type )
    {
        case 'paged':

            if ( class_exists( 'Jetpack' ) && in_array( 'infinite-scroll', Jetpack::get_active_modules() ) )
            {
                return;
            }

            $pagenum_link = html_entity_decode( get_pagenum_link() );
            $query_args   = array();
            $url_parts    = explode( '?', $pagenum_link );

            if ( isset( $url_parts[1] ) )
            {
                wp_parse_str( $url_parts[1], $query_args );
            }

            $pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
            $pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

            // Set up paginated links.
            $links = paginate_links( array(
                'base'     => $pagenum_link,
                'total'    => $query->max_num_pages,
                'current'  => $paged,
                'mid_size' => 1,
                'add_args' => array_map( 'urlencode', $query_args ),
                'prev_text' => '<span class="screen-reader-text">' . esc_html__( 'Previous Page', 'marketingfirm' ) . '</span><i class="fa fa-angle-left"></i>',
                'next_text' => '<span class="screen-reader-text">' . esc_html__( 'Next Page', 'marketingfirm' ) . '</span><i class="fa fa-angle-right"></i>',
            ) );

            $template = '
            <nav class="navigation posts-pagination">
                <h2 class="screen-reader-text">%1$s</h2>
                <div class="posts-page-links">%2$s</div>
            </nav>';

            if ( $links )
            {
                printf(
                    $template,
                    esc_html__( 'Navigation', 'marketingfirm' ),
                    $links
                );
            }
            break;
        
        default:
            the_posts_navigation();
            break;
    }
}


/**
 * Prints post navigation on single view
 *
 * @since 1.0
 */
function travelagency_post_navigation()
{
    $previous = get_previous_post();
    $next = get_next_post();

    ob_start();

    if ( $previous || $next )
    {
        if ( $previous )
        {
            echo '<div class="nav-previous">';

            printf( 
                '<a href="%1$s" rel="prev">%2$s</a>',
                esc_url( get_permalink( $previous->ID ) ),
                esc_html( $previous->post_title )
            );

            echo '</div>'; // Close it
        }

        if ( $next )
        {
            echo '<div class="nav-next">';

            printf( 
                '<a href="%1$s" rel="next">%2$s</a>',
                esc_url( get_permalink( $next->ID ) ),
                esc_html( $next->post_title )
            );

            echo '</div>'; // Close it
        }
    }

    $output = ob_get_clean();

    if ( strlen( $output ) )
    {
        printf(
            '<nav class="post-navigation">
                <h2 class="screen-reader-text">%1$s</h2>
                <div class="nav-links">%2$s</div>
            </nav>',
            esc_html__( 'Post navigation', 'marketingfirm' ),
            $output
        );
    }
}


/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function travelagency_entry_footer()
{
    $top_part_output = '';

    /* translators: used between list items, there is a space after the comma */
    if ( 'post' == get_post_type() && ! post_password_required() && $tags_list = get_the_tag_list( '', ' ' ) )
    {
        $top_part_output .= sprintf(
            '<div class="tags-links">%s</div>',
            $tags_list
        );
    }

    if ( $top_part_output )
    {
        $top_part_output = sprintf( '<div class="top-part clear">%s</div>', $top_part_output );
    }

    ob_start();

    edit_post_link(
        sprintf(
            /* translators: %s: Name of current post */
            esc_html__( 'Edit %s', 'marketingfirm' ),
            the_title( '<span class="screen-reader-text">"', '"</span>', false )
        ),
        '<span class="edit-link">',
        '</span>'
    );

    if ( 'post' == get_post_type() )
    {
        travelagency_social_shares();
    }

    $bottom_part_output = ob_get_clean();

    if ( $bottom_part_output )
    {
        $bottom_part_output = sprintf( '<div class="bottom-part clear">%s</div>', $bottom_part_output );
    }

    if ( $top_part_output || $bottom_part_output )
    {
        printf( '<footer class="entry-footer">%s%s</footer>', $top_part_output, $bottom_part_output );
    }
}


/**
 * Print pagination on single view when applicable
 * @param  boolean $echo
 */
function travelagency_link_pages( $echo = true )
{
    ob_start();

    wp_link_pages( array(
        'before' => '<div class="page-links"><span class="screen-reader-text">' . esc_html__( 'Pages:', 'marketingfirm' ) . '</span>',
        'after'  => '</div>',
        'link_before' => '<span class="page-link-text">',
        'link_after' => '</span>'
    ) );

    if ( $echo )
    {
        echo ob_get_clean();
    }
    else
    {
        return ob_get_clean();
    }
}

/**
 * Prints social share links/icons based on theme mods.
 */
function travelagency_social_shares()
{
    if ( ! class_exists( 'TravelAgency_Social_Share' ) )
    {
        return;
    }
    
    $link_args['facebook']  = get_theme_mod( 'share_facebook_on', true ) ? true : false;
    $link_args['twitter']   = get_theme_mod( 'share_twitter_on', true ) ? true : false;
    $link_args['pinterest'] = get_theme_mod( 'share_pinterest_on', true ) ? true : false;
    $link_args['google']    = get_theme_mod( 'share_google_on', true ) ? true : false;
    $link_args['linkedin']  = get_theme_mod( 'share_linkedin_on' ) ? true : false;
    $link_args['tumblr']    = get_theme_mod( 'share_tumblr_on' ) ? true : false;
    $link_args['vk']        = get_theme_mod( 'share_vk_on' ) ? true : false;
    $link_args['reddit']    = get_theme_mod( 'share_reddit_on' ) ? true : false;
    $link_args['email']     = get_theme_mod( 'share_email_on' ) ? true : false;

    $share = new TravelAgency_Social_Share( $link_args );

    if ( ! empty( $share->links ) )
    {
        echo '<ul class="entry-share-links">';

        foreach ( $share->links as $key => $link )
        {
            switch ( $key )
            {
                case 'facebook':
                    echo '<li class="' . esc_attr( $key ) . '">';
                    echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['label'] ) . '" target="_blank">';
                    echo '<i class="share-icon fab fa-facebook-f"></i>';
                    echo esc_html( $link['label'] );
                    echo '</a>';
                    echo '</li>';
                    break;
                
                case 'twitter':
                    echo '<li class="' . esc_attr( $key ) . '">';
                    echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['label'] ) . '" target="_blank">';
                    echo '<i class="share-icon fab fa-twitter"></i>';
                    echo esc_html( $link['label'] );
                    echo '</a>';
                    echo '</li>';
                    break;

                case 'google':
                    echo '<li class="' . esc_attr( $key ) . '">';
                    echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['label'] ) . '" target="_blank">';
                    echo '<i class="share-icon fab fa-google-plus-g"></i>';
                    echo esc_html( $link['label'] );
                    echo '</a>';
                    echo '</li>';
                    break;

                case 'pinterest':
                    echo '<li class="' . esc_attr( $key ) . '">';
                    echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['label'] ) . '" target="_blank">';
                    echo '<i class="share-icon fab fa-pinterest-p"></i>';
                    echo esc_html( $link['label'] );
                    echo '</a>';
                    break;

                case 'linkedin':
                    echo '<li class="' . esc_attr( $key ) . '">';
                    echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['label'] ) . '" target="_blank">';
                    echo '<i class="share-icon fab fa-linkedin"></i>';
                    echo esc_html( $link['label'] );
                    echo '</a>';
                    break;

                case 'tumblr':
                    echo '<li class="' . esc_attr( $key ) . '">';
                    echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['label'] ) . '" target="_blank">';
                    echo '<i class="share-icon fab fa-tumblr"></i>';
                    echo esc_html( $link['label'] );
                    echo '</a>';
                    break;

                case 'vk':
                    echo '<li class="' . esc_attr( $key ) . '">';
                    echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['label'] ) . '" target="_blank">';
                    echo '<i class="share-icon fab fa-vk"></i>';
                    echo esc_html( $link['label'] );
                    echo '</a>';
                    break;

                case 'reddit':
                    echo '<li class="' . esc_attr( $key ) . '">';
                    echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['label'] ) . '" target="_blank">';
                    echo '<i class="share-icon fab fa-reddit-alien"></i>';
                    echo esc_html( $link['label'] );
                    echo '</a>';
                    break;

                case 'email':
                    echo '<li class="' . esc_attr( $key ) . '">';
                    echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['label'] ) . '" target="_blank">';
                    echo '<i class="share-icon fab fa-envelope-o"></i>';
                    echo esc_html( $link['label'] );
                    echo '</a>';
                    break;

                default:
                    break;
            }
        }

        echo '</ul>';
    }
}


/**
 * Print social markup based on theme customize
 */
function travelagency_social_markup()
{
    $data = get_theme_mod( 'social_profiles', array(
        array(
            'title' => esc_html__( 'Follow on Facebook', 'marketingfirm' ),
            'icon'  => 'font-awesome|fa fa-facebook',
            'url'   => '#'
        ),
        array(
            'title' => esc_html__( 'Follow on Twitter', 'marketingfirm' ),
            'icon'  => 'font-awesome|fa fa-twitter',
            'url'   => '#'
        ),
        array(
            'title' => esc_html__( 'Follow on Instagram', 'marketingfirm' ),
            'icon'  => 'font-awesome|fa fa-instagram',
            'url'   => '#'
        ),
        array(
            'title' => esc_html__( 'Follow on Google', 'marketingfirm' ),
            'icon'  => 'font-awesome|fa fa-google-plus',
            'url'   => '#'
        ),
        array(
            'title' => esc_html__( 'Follow on Behance', 'marketingfirm' ),
            'icon'  => 'font-awesome|fa fa-behance',
            'url'   => '#'
        ),
        array(
            'title' => esc_html__( 'Follow on Dribbble', 'marketingfirm' ),
            'icon'  => 'font-awesome|fa fa-dribbble',
            'url'   => '#'
        )
    ) );

    if ( ! is_array( $data ) || empty( $data ) )
    {
        $data = array();
    }

    ob_start();

    foreach ( $data as $profile )
    {
        $profile = wp_parse_args( $profile, array(
            'title' => '',
            'icon'  => '',
            'url'   => ''
        ) );

        if ( ! $profile['icon'] || ! $profile['url'] )
        {
            continue;
        }

        $icon_varr = explode( '|', $profile['icon'] );
        $icon_class = '';

        if ( count( $icon_varr ) >= 2 )
        {
            $icon_class = $icon_varr[1];
        }

        if ( ! $icon_class )
        {
            continue;
        }

        printf(
            '<li><a href="%1$s" title="%2$s"><i class="%3$s"></i></a></li>',
            esc_url( $profile['url'] ),
            esc_attr( $profile['title'] ),
            esc_attr( $icon_class )
        );
    }

    $output = ob_get_clean();

    if ( $output )
    {
        printf( '<ul class="list-social">%s</ul>', $output );
    }
}
