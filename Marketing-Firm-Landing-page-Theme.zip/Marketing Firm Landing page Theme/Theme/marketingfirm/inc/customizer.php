<?php
/**
 * Travel Agency Theme Customizer
 *
 * @package marketingfirm
 */

/**
 * Register core settings/controls for customize with theme-support
 */
function travelagency_customize_setup()
{
    add_theme_support( 'custom-header', apply_filters( 'travelagency_custom_header_args', array(
        'default-image'    => get_template_directory_uri() . '/images/pheader.jpg',
        'width'            => 1920,
        'flex-width'       => true,
        'height'           => 1080,
        'flex-height'      => true,
        'video'            => false
    ) ) );

    add_theme_support( 'custom-logo', apply_filters( 'travelagency_custom_logo_args', array(
        'default-image' => get_template_directory_uri() . '/images/logo.png',
        'height'        => 240,
        'width'         => 240,
        'flex_height'   => true,
        'flex_width'    => true,
    ) ) );

    // Add theme support for selective refresh for widgets.
    add_theme_support( 'customize-selective-refresh-widgets' );
}
add_action( 'after_setup_theme', 'travelagency_customize_setup' );


/**
 * Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function travelagency_customize_register( $wp_customize )
{
    $wp_customize->register_control_type( 'TravelAgency_Customize_RGBAColor_Control' );
    $wp_customize->register_control_type( 'TravelAgency_Customize_Images_Control' );
    $wp_customize->register_control_type( 'TravelAgency_Customize_Icon_Control' );
    $wp_customize->register_control_type( 'TravelAgency_Customize_Editor_Control' );
    $wp_customize->register_control_type( 'TravelAgency_Customize_Misc_Control' );

    // This control requires all rgba, images, icon and editor controls to be registered
    $wp_customize->register_control_type( 'TravelAgency_Customize_Repeater_Control' );

    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

    // Remove the core header textcolor control, as it shares the main text color.
    $wp_customize->remove_control( 'header_textcolor' );

    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial( 'blogname', array(
            'selector'        => '.site-title a',
            'render_callback' => 'travelagency_customize_partial_blogname',
        ) );
        $wp_customize->selective_refresh->add_partial( 'blogdescription', array(
            'selector'        => '.site-description',
            'render_callback' => 'travelagency_customize_partial_blogdescription',
        ) );
    }

    /*--------------------------------------------------------------
    # Necessary variables
    --------------------------------------------------------------*/

    $pages = get_pages();
    $page_choices = array(
        0 => esc_html__( 'Select a Page', 'marketingfirm' )
    );

    foreach( $pages as $p )
    {
        $page_choices[ $p->ID ] = $p->post_title;
    }

    /*--------------------------------------------------------------
    # OPTIONS PANEL
    --------------------------------------------------------------*/
    
    $wp_customize->add_panel( 'panel_travelagency_options', array(
        'title'      => esc_html__( 'Theme Options', 'marketingfirm' ),
        'capability' => 'edit_theme_options',
    ) );

	
       if ( $wp_customize->get_section( 'title_tagline' ) )
        {
            $wp_customize->get_section( 'title_tagline' )->panel = 'panel_travelagency_options';
            $wp_customize->get_section( 'title_tagline' )->title = esc_html__( 'Header', 'marketingfirm' );
        }

       /* $wp_customize->add_setting( 'taheader_text', array(
            'default' => esc_html__( 'Header custom text', 'marketingfirm' ),
            'sanitize_callback' => 'wp_kses_post'
        ) );

        $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'taheader_text', array(
            'label'           => esc_html__( 'Header Custom Text', 'marketingfirm' ),
            'description'     => esc_html__( 'This custom text show on the left side of logo.', 'marketingfirm' ),
            'section'         => 'title_tagline',
            'priority'        => 45 // After "Display Site Title and Tagline"
        ) ) );
*/
		
		
        if ( $wp_customize->get_section( 'background_image' ) )
        {
            $wp_customize->get_section( 'background_image' )->panel = 'panel_travelagency_options';
        }

        /* Page header area
        ----------------------------------------------------
        $wp_customize->add_section( 'section_travelagency_pheader', array(
            'title'              => esc_html__( 'Page Header', 'marketingfirm' ),
            'description'        => esc_html__( 'Settings for page title area of the current page view.', 'marketingfirm' ),
            'description_hidden' => true,
            'panel'              => 'panel_travelagency_options',
        ) );

            if ( $wp_customize->get_control( 'header_image' ) )
            {
                $wp_customize->get_control( 'header_image' )->section = 'section_travelagency_pheader';
            }
*/
        // Social sharing
        //--------------------------------------------------
        
        $wp_customize->add_section( 'section_travelagency_social_shares', array(
            'title'              => esc_html__( 'Social Sharing', 'marketingfirm' ),
            'description'        => esc_html__( "Social sharing for post, if you don't need it just disable everything here", 'marketingfirm' ),
            'description_hidden' => true,
            'panel'              => 'panel_travelagency_options'
        ) );

            $wp_customize->add_setting( 'share_facebook_on', array( 'default' => true, 'sanitize_callback' => 'absint' ) );
            $wp_customize->add_control( 'share_facebook_on', array(
                'label'         => esc_html__( 'Facebook Sharing Support', 'marketingfirm' ),
                'section'       => 'section_travelagency_social_shares',
                'type'          => 'checkbox'
            ) );

            $wp_customize->add_setting( 'share_twitter_on', array( 'default' => true, 'sanitize_callback' => 'absint' ) );
            $wp_customize->add_control( 'share_twitter_on', array(
                'label'         => esc_html__( 'Twitter Sharing Support', 'marketingfirm' ),
                'section'       => 'section_travelagency_social_shares',
                'type'          => 'checkbox'
            ) );

            $wp_customize->add_setting( 'share_pinterest_on', array( 'default' => true, 'sanitize_callback' => 'absint' ) );
            $wp_customize->add_control( 'share_pinterest_on', array(
                'label'         => esc_html__( 'Pinterest Sharing Support', 'marketingfirm' ),
                'section'       => 'section_travelagency_social_shares',
                'type'          => 'checkbox'
            ) );

            $wp_customize->add_setting( 'share_google_on', array( 'default' => true, 'sanitize_callback' => 'absint' ) );
            $wp_customize->add_control( 'share_google_on', array(
                'label'         => esc_html__( 'Google Sharing Support', 'marketingfirm' ),
                'section'       => 'section_travelagency_social_shares',
                'type'          => 'checkbox'
            ) );

            $wp_customize->add_setting( 'share_linkedin_on', array( 'default' => false, 'sanitize_callback' => 'absint' ) );
            $wp_customize->add_control( 'share_linkedin_on', array(
                'label'         => esc_html__( 'Linkedin Sharing Support', 'marketingfirm' ),
                'section'       => 'section_travelagency_social_shares',
                'type'          => 'checkbox'
            ) );

            $wp_customize->add_setting( 'share_tumblr_on', array( 'default' => false, 'sanitize_callback' => 'absint' ) );
            $wp_customize->add_control( 'share_tumblr_on', array(
                'label'         => esc_html__( 'Tumblr Sharing Support', 'marketingfirm' ),
                'section'       => 'section_travelagency_social_shares',
                'type'          => 'checkbox'
            ) );

            $wp_customize->add_setting( 'share_vk_on', array( 'default' => false, 'sanitize_callback' => 'absint' ) );
            $wp_customize->add_control( 'share_vk_on', array(
                'label'         => esc_html__( 'Vk Sharing Support', 'marketingfirm' ),
                'section'       => 'section_travelagency_social_shares',
                'type'          => 'checkbox'
            ) );

            $wp_customize->add_setting( 'share_reddit_on', array( 'default' => false, 'sanitize_callback' => 'absint' ) );
            $wp_customize->add_control( 'share_reddit_on', array(
                'label'         => esc_html__( 'Reddit Sharing Support', 'marketingfirm' ),
                'section'       => 'section_travelagency_social_shares',
                'type'          => 'checkbox'
            ) );

            $wp_customize->add_setting( 'share_email_on', array( 'default' => false, 'sanitize_callback' => 'absint' ) );
            $wp_customize->add_control( 'share_email_on', array(
                'label'         => esc_html__( 'Email Sharing Support', 'marketingfirm' ),
                'section'       => 'section_travelagency_social_shares',
                'type'          => 'checkbox'
            ) );

        /* Footer area
        ----------------------------------------------------*/
        $wp_customize->add_section( 'section_travelagency_footer', array(
            'title'              => esc_html__( 'Footer', 'marketingfirm' ),
            'description'        => esc_html__( 'Settings for footer area.', 'marketingfirm' ),
            'description_hidden' => true,
            'panel'              => 'panel_travelagency_options',
        ) );

            $wp_customize->add_setting( 'footer_logo', array(
                'theme_supports' => array( 'custom-logo' ),
                'sanitize_callback' => 'absint'
            ) );
            $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'footer_logo', array(
                'label'         => esc_html__( 'Footer Logo', 'marketingfirm' ),
                'section'       => 'section_travelagency_footer',
                'width'         => 240,
                'height'        => 240,
                'flex-width'    => false,
                'flex-height'   => true
            ) ) );
			
            $wp_customize->add_setting( 'footer-text', array(
                'sanitize_callback' => 'wp_kses_post',
                'default' => 'address'
            ) );
            $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'footer-text', array(
                'label'    => esc_html__( 'Address', 'marketingfirm' ),
                'section'  => 'section_travelagency_footer',
                'settings' => 'footer-text'
            ) ) );

			//start newletter
            $wp_customize->add_setting( 'footer-text_newletter', array(
                'sanitize_callback' => 'wp_kses_post',
                'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis '
            ) );
            $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'footer-text_newletter', array(
                'label'    => esc_html__( 'Newletter text', 'marketingfirm' ),
                'section'  => 'section_travelagency_footer',
                'settings' => 'footer-text_newletter'
            ) ) ); 
			
            $wp_customize->add_setting( 'footer_newsletter_sc', array(
                'sanitize_callback' => 'sanitize_text_field',
                'default' => ''
            ) );
            $wp_customize->add_control( 'footer_newsletter_sc', array(
                'type'        => 'text',
                'label'       => esc_html__( 'Newsletter Shortcode', 'marketingfirm' ),
                'description' => esc_html__( 'Please install MailChimp plugin, create a form, then enter form shortcode here.', 'marketingfirm' ),
                'section'     => 'section_travelagency_footer'
            ) );
//
					
            $wp_customize->add_setting( 'footer-text_newletter1', array(
                'sanitize_callback' => 'wp_kses_post',
                'default' => 'You can unsuscribe anytime, Please click here to unsuscribe now'
            ) );
            $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'footer-text_newletter1', array(
                'label'    => esc_html__( 'Newletter Unsuscribe Text', 'marketingfirm' ),
                'section'  => 'section_travelagency_footer',
                'settings' => 'footer-text_newletter1'
            ) ) );			
			
/*
            $wp_customize->add_setting( 'footer_img', array(
                'sanitize_callback' => 'esc_url_raw',
                'default'           => get_template_directory_uri() . '/images/footer.jpg'
            ) );
            $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'footer_img', array(
                'label'           => esc_html__( 'Background Image', 'marketingfirm' ),
                'section'         => 'section_travelagency_footer',
                'priority'        => 20
            ) ) );
*/
//Start social footer
			$wp_customize->add_setting( 'facebook_btn_link', array(
				'sanitize_callback' => 'esc_url',
				'default'           => '#'
			) );
			$wp_customize->add_control( 'facebook_btn_link', array(
				'label'           => esc_html__( 'Facebook Link', 'marketingfirm' ),
				'type'            => 'url',
				'section'         => 'section_travelagency_footer',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) );
//Start social twitter
			$wp_customize->add_setting( 'twitter_btn_link', array(
				'sanitize_callback' => 'esc_url',
				'default'           => '#'
			) );
			$wp_customize->add_control( 'twitter_btn_link', array(
				'label'           => esc_html__( 'Twitter Link', 'marketingfirm' ),
				'type'            => 'url',
				'section'         => 'section_travelagency_footer',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) );
//Start social Instagram
			$wp_customize->add_setting( 'instagram_btn_link', array(
				'sanitize_callback' => 'esc_url',
				'default'           => '#'
			) );
			$wp_customize->add_control( 'instagram_btn_link', array(
				'label'           => esc_html__( 'Instagram Link', 'marketingfirm' ),
				'type'            => 'url',
				'section'         => 'section_travelagency_footer',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) );
//Start social Google
			$wp_customize->add_setting( 'google_btn_link', array(
				'sanitize_callback' => 'esc_url',
				'default'           => '#'
			) );
			$wp_customize->add_control( 'google_btn_link', array(
				'label'           => esc_html__( 'Google Link', 'marketingfirm' ),
				'type'            => 'url',
				'section'         => 'section_travelagency_footer',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) );
//Start social Linkedin
			$wp_customize->add_setting( 'linkedin_btn_link', array(
				'sanitize_callback' => 'esc_url',
				'default'           => '#'
			) );
			$wp_customize->add_control( 'linkedin_btn_link', array(
				'label'           => esc_html__( 'Linkedin Link', 'marketingfirm' ),
				'type'            => 'url',
				'section'         => 'section_travelagency_footer',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) );

            $wp_customize->add_setting( 'copyright_info', array(
                'sanitize_callback' => 'wp_kses_post',
                'default' => '(C) 2018. All Rights Reserved. Parker Travel Agency. Designed by Template.net'
            ) );
			
            $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'copyright_info', array(
                'label'    => esc_html__( 'Copyright Info', 'marketingfirm' ),
                'section'  => 'section_travelagency_footer',
                'settings' => 'copyright_info'
            ) ) );		

    /*--------------------------------------------------------------
    # HERO PANEL
    --------------------------------------------------------------*/
    $wp_customize->add_panel( 'panel_travelagency_hero', array(
        'title'      => esc_html__( 'Section: We provide', 'marketingfirm' ),
        'capability' => 'edit_theme_options',
        'active_callback' => 'travelagency_customize_ac_frontpage'
    ) );

        $wp_customize->add_section( 'section_travelagency_hero_settings', array(
            'title' => esc_html__( 'Settings', 'marketingfirm' ),
            'panel' => 'panel_travelagency_hero'
        ) );

            $wp_customize->add_setting( 'hero_off', array(
                'sanitize_callback' => 'absint',
                'default' => 0
            ) );
            $wp_customize->add_control( 'hero_off', array(
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Hide this section?', 'marketingfirm' ),
                'section'     => 'section_travelagency_hero_settings',
                'description' => esc_html__( 'Check this box to hide this section.', 'marketingfirm' ),
            ) );

            $wp_customize->add_setting( 'hero_img', array(
                'sanitize_callback' => 'esc_url_raw',
                'default'           => get_template_directory_uri() . '/images/hero.jpg'
            ) );
            $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hero_img', array(
                'label'           => esc_html__( 'Background Image', 'marketingfirm' ),
                'section'         => 'section_travelagency_hero_settings',
                'active_callback' => 'travelagency_customize_ac_frontpage_controls'
            ) ) );

         /*   $wp_customize->add_setting( 'hero_title', array(
                'sanitize_callback' => 'travelagency_sanitize_section_title',
                'default'           => esc_html__( 'Travel is the only thing you buy that makes you rich', 'marketingfirm' )
            ) );
            $wp_customize->add_control( 'hero_title', array(
                'label'           => esc_html__( 'Section Title', 'marketingfirm' ),
                'type'            => 'text',
                'section'         => 'section_travelagency_hero_settings',
                'active_callback' => 'travelagency_customize_ac_frontpage_controls'
            ) );
*/
            $wp_customize->add_setting( 'hero_desc', array(
                'sanitize_callback' => 'wp_kses_post',
                'default'           => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.'
            ) );
            $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'hero_desc', array(
                'label'           => esc_html__( 'Section Description', 'marketingfirm' ),
                'section'         => 'section_travelagency_hero_settings',
                'active_callback' => 'travelagency_customize_ac_frontpage_controls'
            ) ) );

            $wp_customize->add_setting( 'hero_id', array(
                'sanitize_callback' => 'travelagency_sanitize_section_id',
                'default'           => 'hero'
            ) );
            $wp_customize->add_control( 'hero_id', array(
                'label'           => esc_html__( 'Section ID', 'marketingfirm' ),
                'type'            => 'text',
                'section'         => 'section_travelagency_hero_settings',
                'description'     => esc_html__( 'The section id, we will use this for link anchor.', 'marketingfirm' ),
                'active_callback' => 'travelagency_customize_ac_frontpage_controls'
            ) );

    /*--------------------------------------------------------------
    # PLACES PANEL
    --------------------------------------------------------------*/
    $wp_customize->add_section( 'section_travelagency_places_settings', array(
        'title' => esc_html__( 'Section: Who we are', 'marketingfirm' ),
        'active_callback' => 'travelagency_customize_ac_frontpage'
    ) );

        $wp_customize->add_setting( 'places_off', array(
            'sanitize_callback' => 'absint',
            'default' => 0
        ) );
        $wp_customize->add_control( 'places_off', array(
            'type'        => 'checkbox',
            'label'       => esc_html__( 'Hide this section?', 'marketingfirm' ),
            'section'     => 'section_travelagency_places_settings',
            'description' => esc_html__( 'Check this box to hide this section.', 'marketingfirm' ),
        ) );
		// Item 0
        $wp_customize->add_setting( 'places_title', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'Who we are!', 'marketingfirm' )
        ) );

        $wp_customize->add_control( 'places_title', array(
            'label'           => esc_html__( 'Section Title box 1', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );		
		
        $wp_customize->add_setting( 'places_desc', array(
            'sanitize_callback' => 'wp_kses_post',
            'default'           => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.'
        ) );
        $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'places_desc', array(
            'label'           => esc_html__( 'Section Description box 1', 'marketingfirm' ),
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) ) );

		// item1
		
        $wp_customize->add_setting( 'places_title_1', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'what we do', 'marketingfirm' )
        ) );

        $wp_customize->add_control( 'places_title_1', array(
            'label'           => esc_html__( 'Section Title box 2', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );			
		
        $wp_customize->add_setting( 'places_desc1', array(
            'sanitize_callback' => 'wp_kses_post',
            'default'           => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.'
        ) );
        $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'places_desc1', array(
            'label'           => esc_html__( 'Section Description box 2', 'marketingfirm' ),
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) ) );		
		
		
		
		// item2
		
        $wp_customize->add_setting( 'places_title_2', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'Why choose us', 'marketingfirm' )
        ) );

        $wp_customize->add_control( 'places_title_2', array(
            'label'           => esc_html__( 'Section Title box 3', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );			
		
        $wp_customize->add_setting( 'places_desc2', array(
            'sanitize_callback' => 'wp_kses_post',
            'default'           => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.'
        ) );
        $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'places_desc2', array(
            'label'           => esc_html__( 'Section Description box 3', 'marketingfirm' ),
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) ) );		
		
		// item3
		
        $wp_customize->add_setting( 'places_title_3', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'How we do', 'marketingfirm' )
        ) );

        $wp_customize->add_control( 'places_title_3', array(
            'label'           => esc_html__( 'Section Title box 4', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );			
		
        $wp_customize->add_setting( 'places_desc3', array(
            'sanitize_callback' => 'wp_kses_post',
            'default'           => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.'
        ) );
        $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'places_desc3', array(
            'label'           => esc_html__( 'Section Description box 4', 'marketingfirm' ),
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) ) );		
		

     /*   $wp_customize->add_setting( 'places_posts_num', array(
            'sanitize_callback' => 'absint',
            'default'           => 3
        ) );
        $wp_customize->add_control( 'places_posts_num', array(
            'label'           => esc_html__( 'Number of Posts', 'marketingfirm' ),
            'type'            => 'select',
            'choices'         => array(
                '2' => '2',
                '3' => '3',
                '4' => '4',
                '5' => '5',
                '6' => '6',
                '7' => '7',
                '8' => '8'
            ),
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );

        $wp_customize->add_setting( 'places_posts_col', array(
            'sanitize_callback' => 'absint',
            'default'           => 3
        ) );
        $wp_customize->add_control( 'places_posts_col', array(
            'label'           => esc_html__( 'Number of Columns', 'marketingfirm' ),
            'type'            => 'select',
            'choices'         => array(
                '2' => '2',
                '3' => '3',
                '4' => '4'
            ),
            'section'         => 'section_travelagency_places_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );
		*/
        $wp_customize->add_setting( 'places_id', array(
            'sanitize_callback' => 'travelagency_sanitize_section_id',
            'default'           => 'places'
        ) );
        $wp_customize->add_control( 'places_id', array(
            'label'           => esc_html__( 'Section ID', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_places_settings',
            'description'     => esc_html__( 'The section id, we will use this for link anchor.', 'marketingfirm' ),
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );

		

    /*--------------------------------------------------------------
    # PROMOTION
    --------------------------------------------------------------*/
    $wp_customize->add_section( 'section_travelagency_promotion_settings', array(
        'title' => esc_html__( 'Section: Marketing provide ', 'marketingfirm' ),
        'capability' => 'edit_theme_options',
        'active_callback' => 'travelagency_customize_ac_frontpage'
    ) );

        $wp_customize->add_setting( 'promotion_off', array(
            'sanitize_callback' => 'absint',
            'default' => 0
        ) );
        $wp_customize->add_control( 'promotion_off', array(
            'type'        => 'checkbox',
            'label'       => esc_html__( 'Hide this section?', 'marketingfirm' ),
            'section'     => 'section_travelagency_promotion_settings',
            'description' => esc_html__( 'Check this box to hide this section.', 'marketingfirm' ),
        ) );

        $wp_customize->add_setting( 'promotion_img', array(
            'sanitize_callback' => 'esc_url_raw',
            'default'           => get_template_directory_uri() . '/images/promotion.jpg'
        ) );
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'promotion_img', array(
            'label'           => esc_html__( 'Background', 'marketingfirm' ),
            'section'         => 'section_travelagency_promotion_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) ) );

        $wp_customize->add_setting( 'promotion_title', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'Get Travel the World Through Parker Travel Agency', 'marketingfirm' )
        ) );
        $wp_customize->add_control( 'promotion_title', array(
            'label'           => esc_html__( 'Section Title', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_promotion_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );

        $wp_customize->add_setting( 'promotion_desc', array(
            'sanitize_callback' => 'wp_kses_post',
            'default'           => 'ras neque orci, egestas ac aliquam eget, maximus ut nisl. Donec in aliquet erat. Nam non ante interdum, gravida ligula in, iaculis ipsum. Vivamus venenatis consectetur finibus. Morbi non lorem rhoncus, porta enim nec, viverra elit. Mauris placerat aliquet erat. Nam non ante interdum, gravida ligula in, iaculis ipsum.'
        ) );
        $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'promotion_desc', array(
            'label'           => esc_html__( 'Section Description', 'marketingfirm' ),
            'section'         => 'section_travelagency_promotion_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) ) );
// add coun 


//end
        $wp_customize->add_setting( 'promotion_title1', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'Online Marketing', 'marketingfirm' )
        ) );
		
        $wp_customize->add_control( 'promotion_title1', array(
            'label'           => esc_html__( 'Section Title Online Marketing', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_promotion_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );
			
        $wp_customize->add_setting( 'promotion_title11', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( '85', 'marketingfirm' )
        ) );
		
        $wp_customize->add_control( 'promotion_title11', array(
            'label'           => esc_html__( ' Value Online Marketing', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_promotion_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );
					
			
        $wp_customize->add_setting( 'promotion_title2', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'Company Branding', 'marketingfirm' )
        ) );
        $wp_customize->add_control( 'promotion_title2', array(
            'label'           => esc_html__( 'Section Title Company Branding', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_promotion_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );		
        $wp_customize->add_setting( 'promotion_title22', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( '90', 'marketingfirm' )
        ) );
		
        $wp_customize->add_control( 'promotion_title22', array(
            'label'           => esc_html__( ' Value Company Branding', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_promotion_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );
        $wp_customize->add_setting( 'promotion_title3', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'Advertising', 'marketingfirm' )
        ) );
        $wp_customize->add_control( 'promotion_title3', array(
            'label'           => esc_html__( 'Section Title Advertising', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_promotion_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );				
        $wp_customize->add_setting( 'promotion_title33', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( '80', 'marketingfirm' )
        ) );
		
        $wp_customize->add_control( 'promotion_title33', array(
            'label'           => esc_html__( ' Value Advertising', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_promotion_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );
				

		
        $wp_customize->add_setting( 'promotion_id', array(
            'sanitize_callback' => 'travelagency_sanitize_section_id',
            'default'           => 'promotion'
        ) );
        $wp_customize->add_control( 'promotion_id', array(
            'label'           => esc_html__( 'Section ID', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_promotion_settings',
            'description'     => esc_html__( 'The section id, we will use this for link anchor.', 'marketingfirm' ),
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );

		
    /*--------------------------------------------------------------
    # FEATURES
    -------------------------------------------------------------- */
	
	

	$wp_customize->add_panel( 'panel_travelagency_features', array(
			'title'      => esc_html__( 'Section: Features', 'marketingfirm' ),
			'capability' => 'edit_theme_options',
			'active_callback' => 'travelagency_customize_ac_frontpage'
		) );

		$wp_customize->add_section( 'section_travelagency_features_settings', array(
			'title' => esc_html__( 'Settings', 'marketingfirm' ),
			'panel' => 'panel_travelagency_features'
		) );

			$wp_customize->add_setting( 'features_off', array(
				'sanitize_callback' => 'absint',
				'default' => 0
			) );
			$wp_customize->add_control( 'features_off', array(
				'type'        => 'checkbox',
				'label'       => esc_html__( 'Hide this section?', 'marketingfirm' ),
				'section'     => 'section_travelagency_features_settings',
				'description' => esc_html__( 'Check this box to hide this section.', 'marketingfirm' ),
			) );
			
			$wp_customize->add_setting( 'features_desc11', array(
				'sanitize_callback' => 'wp_kses_post',
				'default'           => 'United Marketing has been operating for more than 15 years since 2002 '
			) );
			$wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'features_desc11', array(
				'label'           => esc_html__( 'Section Title', 'marketingfirm' ),
				'section'         => 'section_travelagency_features_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );
			
			$wp_customize->add_setting( 'features_desc', array(
				'sanitize_callback' => 'wp_kses_post',
				'default'           => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.'
			) );
			$wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'features_desc', array(
				'label'           => esc_html__( 'Section Description', 'marketingfirm' ),
				'section'         => 'section_travelagency_features_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );

			$wp_customize->add_setting( 'features_btn_link', array(
				'sanitize_callback' => 'esc_url',
				'default'           => '#'
			) );
			$wp_customize->add_control( 'features_btn_link', array(
				'label'           => esc_html__( 'Button Link', 'marketingfirm' ),
				'type'            => 'url',
				'section'         => 'section_travelagency_features_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) );			
			
			$wp_customize->add_setting( 'features_img', array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => get_template_directory_uri() . '/images/features.jpg'
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'features_img', array(
				'label'           => esc_html__( 'Image', 'marketingfirm' ),
				'section'         => 'section_travelagency_features_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );
			
			$wp_customize->add_setting( 'features_id', array(
				'sanitize_callback' => 'travelagency_sanitize_section_id',
				'default'           => 'features'
			) );
			$wp_customize->add_control( 'features_id', array(
				'label'           => esc_html__( 'Section ID', 'marketingfirm' ),
				'type'            => 'text',
				'section'         => 'section_travelagency_features_settings',
				'description'     => esc_html__( 'The section id, we will use this for link anchor.', 'marketingfirm' ),
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) );


    /*--------------------------------------------------------------
    # LOGO ICON PANEL
    --------------------------------------------------------------*/
	
		$wp_customize->add_section( 'section_travelagency_gallery_settings', array(
			'title' => esc_html__( 'Section: Our client list', 'marketingfirm' ),
			'active_callback' => 'travelagency_customize_ac_frontpage'
		) );

			$wp_customize->add_setting( 'gallery_off', array(
				'sanitize_callback' => 'absint',
				'default' => 0
			) );
			$wp_customize->add_control( 'gallery_off', array(
				'type'        => 'checkbox',
				'label'       => esc_html__( 'Hide this section?', 'marketingfirm' ),
				'section'     => 'section_travelagency_gallery_settings',
				'description' => esc_html__( 'Check this box to hide this section.', 'marketingfirm' ),
			) );

			$wp_customize->add_setting( 'gallery_title', array(
				'sanitize_callback' => 'travelagency_sanitize_section_title',
				'default'           => esc_html__( 'Checkout Our Clients Beautiful Memories', 'marketingfirm' )
			) );
			$wp_customize->add_control( 'gallery_title', array(
				'label'           => esc_html__( 'Section Title', 'marketingfirm' ),
				'type'            => 'text',
				'section'         => 'section_travelagency_gallery_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) );
			
	// Start images 
			$wp_customize->add_setting( 'gallery_img', array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => get_template_directory_uri() . '/images/gallery.jpg'
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gallery_img', array(
				'label'           => esc_html__( 'Client image 1', 'marketingfirm' ),
				'section'         => 'section_travelagency_gallery_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );		
			$wp_customize->add_setting( 'gallery_img2', array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => get_template_directory_uri() . '/images/gallery.jpg'
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gallery_img2', array(
				'label'           => esc_html__( 'Client image 2', 'marketingfirm' ),
				'section'         => 'section_travelagency_gallery_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );			
			$wp_customize->add_setting( 'gallery_img3', array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => get_template_directory_uri() . '/images/gallery.jpg'
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gallery_img3', array(
				'label'           => esc_html__( 'Client image 3', 'marketingfirm' ),
				'section'         => 'section_travelagency_gallery_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );	
			$wp_customize->add_setting( 'gallery_img4', array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => get_template_directory_uri() . '/images/gallery.jpg'
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gallery_img4', array(
				'label'           => esc_html__( 'Client image 4', 'marketingfirm' ),
				'section'         => 'section_travelagency_gallery_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );	

			$wp_customize->add_setting( 'gallery_img5', array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => get_template_directory_uri() . '/images/gallery.jpg'
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gallery_img5', array(
				'label'           => esc_html__( 'Client image 5', 'marketingfirm' ),
				'section'         => 'section_travelagency_gallery_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );	

			$wp_customize->add_setting( 'gallery_img6', array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => get_template_directory_uri() . '/images/gallery.jpg'
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gallery_img6', array(
				'label'           => esc_html__( 'Client image 6', 'marketingfirm' ),
				'section'         => 'section_travelagency_gallery_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );	
			$wp_customize->add_setting( 'gallery_img7', array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => get_template_directory_uri() . '/images/gallery.jpg'
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gallery_img7', array(
				'label'           => esc_html__( 'Client image 7', 'marketingfirm' ),
				'section'         => 'section_travelagency_gallery_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );	
			$wp_customize->add_setting( 'gallery_img8', array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => get_template_directory_uri() . '/images/gallery.jpg'
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gallery_img8', array(
				'label'           => esc_html__( 'Client image 8', 'marketingfirm' ),
				'section'         => 'section_travelagency_gallery_settings',
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) ) );			
	// end images	
			
			
			$wp_customize->add_setting( 'gallery_id', array(
				'sanitize_callback' => 'travelagency_sanitize_section_id',
				'default'           => 'gallery'
			) );
			$wp_customize->add_control( 'gallery_id', array(
				'label'           => esc_html__( 'Section ID', 'marketingfirm' ),
				'type'            => 'text',
				'section'         => 'section_travelagency_gallery_settings',
				'description'     => esc_html__( 'The section id, we will use this for link anchor.', 'marketingfirm' ),
				'active_callback' => 'travelagency_customize_ac_frontpage_controls'
			) );
		
		
	
    /*--------------------------------------------------------------
    # BLOG PANEL
    --------------------------------------------------------------*/
    $wp_customize->add_section( 'section_travelagency_blog_settings', array(
        'title' => esc_html__( 'Section: Read Blog', 'marketingfirm' ),
        'active_callback' => 'travelagency_customize_ac_frontpage'
    ) );

        $wp_customize->add_setting( 'blog_off', array(
            'sanitize_callback' => 'absint',
            'default' => 0
        ) );
        $wp_customize->add_control( 'blog_off', array(
            'type'        => 'checkbox',
            'label'       => esc_html__( 'Hide this section?', 'marketingfirm' ),
            'section'     => 'section_travelagency_blog_settings',
            'description' => esc_html__( 'Check this box to hide this section.', 'marketingfirm' ),
        ) );
/*
        $wp_customize->add_setting( 'blog_img', array(
            'sanitize_callback' => 'esc_url_raw',
            'default'           => get_template_directory_uri() . '/images/blog.jpg'
        ) );
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'blog_img', array(
            'label'           => esc_html__( 'Background Image', 'marketingfirm' ),
            'section'         => 'section_travelagency_blog_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) ) ); */

        $wp_customize->add_setting( 'blog_title', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'Read about beautiful destinations around the world!', 'marketingfirm' )
        ) );
        $wp_customize->add_control( 'blog_title', array(
            'label'           => esc_html__( 'Section Title', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_blog_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );
/*
 */
        $wp_customize->add_setting( 'blog_posts_num', array(
            'sanitize_callback' => 'absint',
            'default'           => 3
        ) );
        $wp_customize->add_control( 'blog_posts_num', array(
            'label'           => esc_html__( 'Number of Posts', 'marketingfirm' ),
            'type'            => 'select',
            'choices'         => array(
                '2' => '2',
                '3' => '3',
                '4' => '4',
                '5' => '5',
                '6' => '6',
                '7' => '7',
                '8' => '8'
            ),
            'section'         => 'section_travelagency_blog_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );

        $wp_customize->add_setting( 'blog_posts_col', array(
            'sanitize_callback' => 'absint',
            'default'           => 3
        ) );
        $wp_customize->add_control( 'blog_posts_col', array(
            'label'           => esc_html__( 'Number of Columns', 'marketingfirm' ),
            'type'            => 'select',
            'choices'         => array(
                '2' => '2',
                '3' => '3',
                '4' => '4'
            ),
            'section'         => 'section_travelagency_blog_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );

        $wp_customize->add_setting( 'blog_id', array(
            'sanitize_callback' => 'travelagency_sanitize_section_id',
            'default'           => 'blog'
        ) );
        $wp_customize->add_control( 'blog_id', array(
            'label'           => esc_html__( 'Section ID', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_blog_settings',
            'description'     => esc_html__( 'The section id, we will use this for link anchor.', 'marketingfirm' ),
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );
			
			
			
    /*--------------------------------------------------------------
    # TESTIMONIALS
    --------------------------------------------------------------*/
    $wp_customize->add_section( 'section_travelagency_testimonials_settings', array(
        'title' => esc_html__( 'Section: Testimonials', 'marketingfirm' ),
        'active_callback' => 'travelagency_customize_ac_frontpage'
    ) );

        $wp_customize->add_setting( 'testimonials_off', array(
            'sanitize_callback' => 'absint',
            'default' => 0
        ) );
        $wp_customize->add_control( 'testimonials_off', array(
            'type'        => 'checkbox',
            'label'       => esc_html__( 'Hide this section?', 'marketingfirm' ),
            'section'     => 'section_travelagency_testimonials_settings',
            'description' => esc_html__( 'Check this box to hide this section.', 'marketingfirm' ),
        ) );

        $wp_customize->add_setting( 'testimonials_title', array(
            'sanitize_callback' => 'travelagency_sanitize_section_title',
            'default'           => esc_html__( 'Client Testimonials', 'marketingfirm' )
        ) );
        $wp_customize->add_control( 'testimonials_title', array(
            'label'           => esc_html__( 'Section Title', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_testimonials_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );
/*
        $wp_customize->add_setting( 'testimonials_desc', array(
            'sanitize_callback' => 'wp_kses_post',
            'default'           => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.'
        ) );
        $wp_customize->add_control( new TravelAgency_Customize_Editor_Control( $wp_customize, 'testimonials_desc', array(
            'label'           => esc_html__( 'Section Description', 'marketingfirm' ),
            'section'         => 'section_travelagency_testimonials_settings',
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) ) );
/*
*/
        $wp_customize->add_setting( 'testimonials_id', array(
            'sanitize_callback' => 'travelagency_sanitize_section_id',
            'default'           => 'testimonials'
        ) );
        $wp_customize->add_control( 'testimonials_id', array(
            'label'           => esc_html__( 'Section ID', 'marketingfirm' ),
            'type'            => 'text',
            'section'         => 'section_travelagency_testimonials_settings',
            'description'     => esc_html__( 'The section id, we will use this for link anchor.', 'marketingfirm' ),
            'active_callback' => 'travelagency_customize_ac_frontpage_controls'
        ) );
	
	

    /*--------------------------------------------------------------
    # RE-ORDERING IF NEEDED
    --------------------------------------------------------------*/
    if ( $panel = $wp_customize->get_panel( 'panel_travelagency_options' ) )
    {
        $panel->priority = 20;
    }
    if ( $panel = $wp_customize->get_panel( 'panel_travelagency_hero' ) )
    {
        $panel->priority = 21;
    }
    if ( $section = $wp_customize->get_section( 'section_travelagency_places_settings' ) )
    {
        $section->priority = 22;
    }
    if ( $section = $wp_customize->get_section( 'section_travelagency_promotion_settings' ) )
    {
        $section->priority = 23;
    }
    if ( $panel = $wp_customize->get_panel( 'panel_travelagency_features' ) )
    {
        $panel->priority = 24;
    }
    if ( $section = $wp_customize->get_section( 'section_travelagency_testimonials_settings' ) )
    {
        $section->priority = 25;
    }
    if ( $section = $wp_customize->get_section( 'section_travelagency_blog_settings' ) )
    {
        $section->priority = 26;
    }
    if ( $section = $wp_customize->get_section( 'section_travelagency_cta_settings' ) )
    {
        $section->priority = 27;
    }
    if ( $section = $wp_customize->get_section( 'section_travelagency_gallery_settings' ) )
    {
        $section->priority = 28;
    }
}
add_action( 'customize_register', 'travelagency_customize_register' );

/**
 * Customizer control scripts
 */
function travelagency_customize_control_scripts()
{
    $editor_styles = get_editor_stylesheets();

    if ( ! empty( $editor_styles ) )
    {
        // Force urlencoding of commas.
        foreach ( $editor_styles as $key => $url )
        {
            if ( strpos( $url, ',' ) !== false )
            {
                $editor_styles[ $key ] = str_replace( ',', '%2C', $url );
            }
        }
    }

    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_style( 'marketingfirm-customizer', get_template_directory_uri() . '/css/customizer.css', array(), null );
    wp_enqueue_script( 'marketingfirm-customizer-control', get_template_directory_uri() . '/js/customize-controls.min.js', array( 'jquery', 'wp-color-picker', 'customize-controls', 'underscore', 'editor' ), '', true );
    wp_localize_script( 'marketingfirm-customizer-control', 'SEditorStyles', $editor_styles );
    wp_enqueue_script( 'marketingfirm-customizer', get_template_directory_uri() . '/js/customizer.js', array(), '', true );
}
add_action( 'customize_controls_enqueue_scripts', 'travelagency_customize_control_scripts' );


/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function travelagency_customize_preview_js()
{
    wp_enqueue_script( 'marketingfirm-customizer', get_template_directory_uri() . '/js/customizer-previews.js', array( 'customize-preview' ), '', true );
}
add_action( 'customize_preview_init', 'travelagency_customize_preview_js' );
