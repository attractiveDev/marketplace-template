<?php
/**
 * Testimonials section for the frontpage
 *
 * @package marketingfirm
 */

if ( get_theme_mod( 'testimonials_off', false ) )
{
    return;
}

$sid  = get_theme_mod( 'testimonials_id', 'testimonials' );
$sid  = travelagency_is_valid_css_id_class( $sid ) ? trim( $sid ) : '';
$atts = array(
    'id'    => $sid,
    'class' => array(
        'section',
        'testimonials-section'
    ),
    'data-eltype' => 'frontpagesection',
    'style'       => array()
);
$section_atts = travelagency_get_html_atts( $atts );

$title = get_theme_mod( 'testimonials_title', esc_html__( 'Client Testimonials', 'marketingfirm' ) );
//$desc  = get_theme_mod( 'testimonials_desc', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.' );
$posts_num = absint( get_theme_mod( 'testimonials_posts_num', 3 ) );
$posts_col = absint( get_theme_mod( 'testimonials_posts_col', 3 ) );
if ( $posts_col <= 1 || $posts_col > 4 )
{
    $posts_col = 3;
}

$posts_query = new WP_Query( array(
    'post_type'           => 'ta_testimonial',
    'post_status'         => 'publish',
    'posts_per_page'      => $posts_num,
    'ignore_sticky_posts' => true
) );
?>
<section <?php echo $section_atts; ?>>
    <div class="container wide-container section-inner">
        <?php 
            if ( $title || $desc )
            {
                echo '<div class="section-header section-header-style-default">';
                if ( $title )
                {
                    printf( '<h2 class="section-title">%s</h2>', wp_kses( $title, travelagency_global_kses( 'inline' ) ) );
                }
                //if ( $desc )
               // {
                 ////   printf( '<div class="section-desc">%s</div>', wpautop( $desc ) );
             //   }
                echo    '<span class="section-header-sep"><span class="section-header-sep-inner"></span></span>';
                echo '</div>';
            }

            if ( $posts_query->have_posts() )
            {
                printf( '<div class="row testimonial-entries testimonial-entries-%scols">', $posts_col );
                $col_classes = 'testimonial-entry-col';
               /* switch ( $posts_col )
                {
                    case 2:
                        $col_classes .= ' col-md-6';
                        break;

                    case 3:
                        $col_classes .= ' col-md-6 col-xl-4';
                        break;

                    case 4:
                        $col_classes .= ' col-md-6 col-xl-3';
                        break;
                    
                    default:
                        break;
                } */
                while ( $posts_query->have_posts() )
                {
                    $posts_query->the_post();
                    echo '<div class="' . esc_attr( $col_classes ) . '">';

                    echo '<div class="testimonial-entry">';
                    echo    '<div class="entry-body">';
                    the_content();
                    echo    '</div>';
                    echo    '<div class="entry-footer">';
                    if ( has_post_thumbnail() )
                    {
                        echo    '<div class="entry-thumbnail">';
                        the_post_thumbnail( 'thumbnail' );
                        echo    '</div>';
                    }
                    echo        '<div class="entry-info">';
                    the_title(      '<h4 class="entry-title">', '</h4>' );
                    $meta = wp_parse_args(
                        maybe_unserialize( get_post_meta( get_the_ID(), '_ta_testimonial_options', true ) ),
                        array( 'info' => '' )
                    );
                    if ( $meta['info'] )
                    {
                        printf(     '<p class="entry-info">%s</p>', $meta['info'] );
                    }
                    echo        '</div>';
                    echo    '</div>';
                    echo '</div>';

                    echo '</div>';
                }

                echo '</div>';
            }
        ?>
		<script>						
			jQuery(document).ready(function($){
				$('.testimonial-entries').slick({
					infinite: true,
					slidesToShow: 2,
					dots: true,
					slidesToScroll: 1,
					responsive: [
						{
						  breakpoint: 1024,
						  settings: {
							slidesToShow: 1,
							slidesToScroll: 1,
							infinite: true,
							dots: true
						  }
						}
					  ]
				});							
				
			});	
		
			
		</script>
		
		
		
    </div>
</section>