<?php
/**
 * features section for the frontpage
 *
 * @package marketingfirm
 */

if ( get_theme_mod( 'features_off', false ) )
{
    return;
}

$sid  = get_theme_mod( 'features_id', 'features' );
$sid  = travelagency_is_valid_css_id_class( $sid ) ? trim( $sid ) : '';
$atts = array(
    'id'    => $sid,
    'class' => array(
        'section',
        'features-section'
    ),
    'data-eltype' => 'frontpagesection',
    'style'       => array()
);
$img_url      = get_theme_mod( 'features_img', get_template_directory_uri() . '/images/features.jpg' );
$section_atts = travelagency_get_html_atts( $atts );

//$title       = get_theme_mod( 'features_title', esc_html__( 'Get Travel the World Through Parker Travel Agency', 'marketingfirm' ) );

$desc11       = get_theme_mod( 'features_desc11', ' United Marketing has been operating for more than 15 years since 2002 ' );

$desc        = get_theme_mod( 'features_desc', 'ras neque orci, egestas ac aliquam eget, maximus ut nisl. Donec in aliquet erat. Nam non ante interdum, gravida ligula in, iaculis ipsum. Vivamus venenatis consectetur finibus. Morbi non lorem rhoncus, porta enim nec, viverra elit. Mauris placerat aliquet erat. Nam non ante interdum, gravida ligula in, iaculis ipsum.' );

$btn_title  = get_theme_mod( 'features_btn_title', esc_html__( 'Learn More', 'marketingfirm' ) );
$btn_link   = get_theme_mod( 'features_btn_link', '#' );
$btn_target = (bool) get_theme_mod( 'features_btn_target' );

?>

<section <?php echo $section_atts; ?>>
    <div class="container wide-container section-inner">
			
            <div class="features-box-body">
                <?php
					if ( $desc11 )
					{
						printf( '<h2 class="section-title-post">%s</h2>', wp_kses_post( $desc11  ) );
					}
                    if ( $title || $desc )
                    {
                        echo '<div class="section-header">';
                        if ( $title )
                        {
                            printf( '<h2 class="section-title">%s</h2>', wp_kses( $title, travelagency_global_kses( 'inline' ) ) );
                        }
                        if ( $desc )
                        {
                            printf( '<div class="section-desc">%s</div>', wp_kses_post( $desc  ) );
                        }
                        echo '</div>';
                    }

                    if ( $btn_title && $btn_link )
                    {
                        echo '<div class="section-actions">';
                        printf(
                            '<a href="%1$s" class=" section-action-link"%2$s><span>%3$s</span></a>',
                            esc_url( $btn_link ),
                            $btn_target ? ' target="_blank"' : ' target="_self"',
                            esc_html( $btn_title )
                        );
                        echo '</div>';
                    }
                ?>
            </div>
			
			<div class="features-box-img<?php //echo ( $img_url ? ' has-thumbnail' : '' ); ?>">
				<?php
					if ( $img_url )
					{
						printf(
							'<div class="features-box-thumbnail"><img src="%s" alt="" /></div>',
							esc_url( $img_url )
						);
					}
				?>
			</div>
			
			
			
			
			
			
        </div>
    </div>
</section>