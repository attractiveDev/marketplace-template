<?php
/**
 * Places section for the frontpage
 *
 * @package marketingfirm
 */

if ( get_theme_mod( 'places_off', false ) )
{
    return;
}

$sid  = get_theme_mod( 'places_id', 'places' );
$sid  = travelagency_is_valid_css_id_class( $sid ) ? trim( $sid ) : '';
$atts = array(
    'id'    => $sid,
    'class' => array(
        'section',
        'places-section'
    ),
    'data-eltype' => 'frontpagesection',
    'style'       => array()
);
$section_atts = travelagency_get_html_atts( $atts );

$title = get_theme_mod( 'places_title', esc_html__( 'Who we are', 'marketingfirm' ) );
$desc  = get_theme_mod( 'places_desc', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.' );
//
$title1 = get_theme_mod( 'places_title1', esc_html__( 'what we do', 'marketingfirm' ) );
$desc1  = get_theme_mod( 'places_desc1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.' );
//
$title2 = get_theme_mod( 'places_title2', esc_html__( 'Why choose us', 'marketingfirm' ) );
$desc2  = get_theme_mod( 'places_desc2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.' );
//
$title3 = get_theme_mod( 'places_title3', esc_html__( 'How we do', 'marketingfirm' ) );
$desc3  = get_theme_mod( 'places_desc3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.' );
//




$posts_num = absint( get_theme_mod( 'places_posts_num', 3 ) );
$posts_col = absint( get_theme_mod( 'places_posts_col', 3 ) );
if ( $posts_col <= 1 || $posts_col > 4 )
{
    $posts_col = 3;
}

$posts_query = new WP_Query( array(
    'post_type'           => 'ta_place',
    'post_status'         => 'publish',
    'posts_per_page'      => $posts_num,
    'ignore_sticky_posts' => true
) );
?>
<section <?php echo $section_atts; ?>>
    <div class="container wide-container section-inner">
        <?php 
		
            if ( $title || $desc )
            {
                echo '<div class="section-header section-header-style-default border-1">';
                if ( $title )
                {
                    printf( '<h2 class="section-title">%s</h2>', wp_kses( $title, travelagency_global_kses( 'inline' ) ) );
                }
                if ( $desc )
                {
                    printf( '<div class="section-desc">%s</div>', wpautop( $desc ) );
                }
                echo    '<span class="section-header-sep"><span class="section-header-sep-inner"></span></span>';
                echo '</div>';
            }
            if ( $title1 || $desc1 )
            {
                echo '<div class="section-header section-header-style-default border-2">';
                if ( $title1 )
                {
                    printf( '<h2 class="section-title">%s</h2>', wp_kses( $title1, travelagency_global_kses( 'inline' ) ) );
                }
                if ( $desc1 )
                {
                    printf( '<div class="section-desc">%s</div>', wpautop( $desc1 ) );
                }
                echo    '<span class="section-header-sep"><span class="section-header-sep-inner"></span></span>';
                echo '</div>';
            }

            if ( $title2 || $desc2 )
            {
                echo '<div class="section-header section-header-style-default border-3">';
                if ( $title2 )
                {
                    printf( '<h2 class="section-title">%s</h2>', wp_kses( $title2, travelagency_global_kses( 'inline' ) ) );
                }
                if ( $desc2 )
                {
                    printf( '<div class="section-desc">%s</div>', wpautop( $desc2 ) );
                }
                echo    '<span class="section-header-sep"><span class="section-header-sep-inner"></span></span>';
                echo '</div>';
            }			
			
            if ( $title3 || $desc3 )
            {
                echo '<div class="section-header section-header-style-default border-4">';
                if ( $title3 )
                {
                    printf( '<h2 class="section-title">%s</h2>', wp_kses( $title3, travelagency_global_kses( 'inline' ) ) );
                }
                if ( $desc3 )
                {
                    printf( '<div class="section-desc">%s</div>', wpautop( $desc3 ) );
                }
                echo    '<span class="section-header-sep"><span class="section-header-sep-inner"></span></span>';
                echo '</div>';
            }			
			
			
			

			
			
			
            if ( $posts_query->have_posts() )
            {
                printf( '<div class="row place-post-entries place-post-entries-%scols">', $posts_col );
                $col_classes = 'place-post-entry-col';
                switch ( $posts_col )
                {
                    case 2:
                        $col_classes .= ' col-md-6';
                        break;

                    case 3:
                        $col_classes .= ' col-md-6 col-xl-4';
                        break;

                    case 4:
                        $col_classes .= ' col-md-6 col-xl-3';
                        break;
                    
                    default:
                        break;
                }
                while ( $posts_query->have_posts() )
                {
                    $posts_query->the_post();
                    echo '<div class="' . esc_attr( $col_classes ) . '">';
                    get_template_part( 'template-parts/loop-place-grid' );
                    echo '</div>';
                }

                echo '</div>';
            }

        ?>
    </div>
</section>