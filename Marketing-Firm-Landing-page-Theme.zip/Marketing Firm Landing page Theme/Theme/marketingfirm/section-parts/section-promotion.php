<?php
/**
 * features section for the frontpage
 *
 * @package marketingfirm
 */

if ( get_theme_mod( 'promotion_off', false ) )
{
    return;
}

$sid  = get_theme_mod( 'promotion_id', 'promotion' );
$sid  = travelagency_is_valid_css_id_class( $sid ) ? trim( $sid ) : '';
$atts = array(
    'id'    => $sid,
    'class' => array(
        'section',
        'promotion-section'
    ),
    'data-eltype' => 'frontpagesection',
    'style'       => array()
);
$img_url      = get_theme_mod( 'promotion_img', get_template_directory_uri() . '/images/features.jpg' );
$section_atts = travelagency_get_html_atts( $atts );

$title       = get_theme_mod( 'promotion_title', esc_html__( 'United Marketing provide various marketing services for your business needs.', 'marketingfirm' ) );
$desc        = get_theme_mod( 'promotion_desc', 'A more comprehensive and innovative way to run the marketing operations of your business. We ensure that all your marketing efforts will work as smoothly as possible and will have positive results.' );

$title1       = get_theme_mod( 'promotion_title1', esc_html__( 'Online Marketing', 'marketingfirm' ) );

$title2       = get_theme_mod( 'promotion_title2', esc_html__( 'Company Branding', 'marketingfirm' ) );

$title3       = get_theme_mod( 'promotion_title3', esc_html__( 'Advertising', 'marketingfirm' ) );
//
$title11       = get_theme_mod( 'promotion_title11', esc_html__( '85', 'marketingfirm' ) );

$title22       = get_theme_mod( 'promotion_title22', esc_html__( '90', 'marketingfirm' ) );

$title33      = get_theme_mod( 'promotion_title33', esc_html__( '85', 'marketingfirm' ) );

//$btn_title  = get_theme_mod( 'promotion_btn_title', esc_html__( 'Learn More', 'marketingfirm' ) );
//$btn_link   = get_theme_mod( 'promotion_btn_link', '#' );
//$btn_target = (bool) get_theme_mod( 'promotion_btn_target' );
?>
<section <?php echo $section_atts; ?>>
	<?php
		if ( $img_url )
		{
			printf(
				'<div class="promotion-box-thumbnail"><img src="%s" alt="" /></div>',
				esc_url( $img_url )
			);
		}
	?>
    <div class="promotion wide-container section-inner">
        <div class=" container">
            <div class="promotion-box-body">
                
				<div class="header-promo">
				<?php
                    if ( $title || $desc )
                    {
                        echo '<div class="section-header">';
                        if ( $title )
                        {
                            printf( '<h2 class="section-title">%s</h2>', wp_kses( $title, travelagency_global_kses( 'inline' ) ) );
                        }
                        if ( $desc )
                        {
                            printf( '<div class="section-desc">%s</div>', wp_kses_post( $desc  ) );
                        }
                        echo '</div>';
                    }
				
					?>
				</div>
				<div class="content-promo">
					<?php
					
                    if ( $title1 || $desc1 )
                    {
                        echo '<div class="section-header">';
                        if ( $title1 )
                        {
                            printf( '<h2 class="section-title">%s</h2>', wp_kses( $title1, travelagency_global_kses( 'inline' ) ) );
                        }
                        if ( $title11 )
                        { ?>
						<div class="value yallow">
							<span style="width:<?php echo $title11.'%' ?>"></span>
						</div>
						<?php
                           // printf( '<h2 class="section-title-value">%s</h2>', wp_kses( $title11, travelagency_global_kses( 'inline' ) ) );
                        }
                        echo '</div>';
                    }
					
                    if ( $title2 || $desc2 )
                    {
                        echo '<div class="section-header">';
                        if ( $title2 )
                        {
                            printf( '<h2 class="section-title ">%s</h2>', wp_kses( $title2, travelagency_global_kses( 'inline' ) ) );
                        }
                        if ( $title22 )
                        { ?>
						<div class="value blue">
							<span style="width:<?php echo $title22.'%' ?>"></span>
						</div>
						<?php
                           // printf( '<h2 class="section-title-value">%s</h2>', wp_kses( $title22, travelagency_global_kses( 'inline' ) ) );
                        }
                        echo '</div>';
                    }
										
					
                    if ( $title3 || $desc3 )
                    {
                        echo '<div class="section-header">';
                        if ( $title3 )
                        {
                            printf( '<h2 class="section-title">%s</h2>', wp_kses( $title3, travelagency_global_kses( 'inline' ) ) );
                        }
						if ( $title33 )
                        { ?>
						<div class="value pink">
							<span style="width:<?php echo $title33.'%' ?>"></span>
						</div>
						<?php
                          //  printf( '<h2 class="section-title-value">%s</h2>', wp_kses( $title33, travelagency_global_kses( 'inline' ) ) );
                        }
                        echo '</div>';
                    }
										
					
					
					
                   /* if ( $btn_title && $btn_link )
                    {
                        echo '<div class="section-actions">';
                        printf(
                            '<a href="%1$s" class="button section-action-link"%2$s>%3$s</a>',
                            esc_url( $btn_link ),
                            $btn_target ? ' target="_blank"' : ' target="_self"',
                            esc_html( $btn_title )
                        );
                        echo '</div>';
                    }
					*/
                ?>
				</div>
            </div>
        </div>
    </div>
</section>