<?php
/**
 * Hero banner section for the frontpage
 *
 * @package marketingfirm
 */

if ( get_theme_mod( 'hero_off', false ) )
{
    return;
}

$sid  = get_theme_mod( 'hero_id', 'hero' );
$sid  = travelagency_is_valid_css_id_class( $sid ) ? trim( $sid ) : '';
$atts = array(
    'id'    => $sid,
    'class' => array(
        'section',
        'hero-section'
    ),
    'data-eltype' => 'frontpagesection',
    'style'       => array()
);
$img_url      = get_theme_mod( 'hero_img', get_template_directory_uri() . '/images/hero.jpg' );
$section_atts = travelagency_get_html_atts( $atts );

$content_img = get_theme_mod( 'hero_content_img', get_template_directory_uri() . '/images/mountain.png' );
//$title       = get_theme_mod( 'hero_title', esc_html__( 'Travel is the only thing you buy that makes you rich', 'marketingfirm' ) );
$desc        = get_theme_mod( 'hero_desc', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.' );

?>
<section <?php echo $section_atts; ?>>
    <div class="section-deco" <?php echo $img_url ? ' style="background-image:url(' . esc_url( $img_url ) . ');"': ''; ?>></div>
    <div class="container wide-container section-inner">
        <div class="section-body">
            <?php
                if ( $title || $desc )
                {
                    echo '<div class="section-header">';
                    if ( $title )
                    {
                        printf( '<h2 class="section-title">%s</h2>', wp_kses( $title, travelagency_global_kses( 'inline' ) ) );
                    }
                    if ( $desc )
                    {
                        printf( '<div class="section-desc">%s</div>', wp_kses_post( $desc  ) );
                    }
                    echo '</div>';
                }
                if ( $content_img )
                {
                    echo '<div class="section-thumbnail">';
                    printf( '<img src="%s" alt="hero-section-thumbnail" />', esc_url( $content_img ) );
                    echo '</div>';
                }
            ?>
        </div>
    </div>
</section>