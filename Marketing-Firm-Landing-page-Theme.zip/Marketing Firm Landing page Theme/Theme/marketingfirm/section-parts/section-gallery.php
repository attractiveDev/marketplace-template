<?php
/**
 * Gallery section for the frontpage
 *
 * @package marketingfirm
 */

if ( get_theme_mod( 'gallery_off', false ) )
{
    return;
}

$sid  = get_theme_mod( 'gallery_id', 'gallery' );
$sid  = travelagency_is_valid_css_id_class( $sid ) ? trim( $sid ) : '';
$atts = array(
    'id'    => $sid,
    'class' => array(
        'section',
        'gallery-section'
    ),
    'data-eltype' => 'frontpagesection',
    'style'       => array()
);
$section_atts = travelagency_get_html_atts( $atts );

$title = get_theme_mod( 'gallery_title', esc_html__( 'Checkout Our Clients Beautiful Memories', 'marketingfirm' ) );
$desc  = get_theme_mod( 'gallery_desc', esc_html__( 'Beautiful photo stream from our instagram page', 'marketingfirm' ) );

$img_url      = get_theme_mod( 'gallery_img', get_template_directory_uri() . '/images/gallery.jpg' );
$section_atts = travelagency_get_html_atts( $atts );
$content_img = get_theme_mod( 'gallery_img', get_template_directory_uri() . '/images/gallery.png' );
//start add

$img_url2      = get_theme_mod( 'gallery_img2', get_template_directory_uri() . '/images/gallery.jpg' );
$section_atts = travelagency_get_html_atts( $atts );
$content_img2 = get_theme_mod( 'gallery_img2', get_template_directory_uri() . '/images/gallery.png' );

$img_url3      = get_theme_mod( 'gallery_img3', get_template_directory_uri() . '/images/gallery.jpg' );
$section_atts = travelagency_get_html_atts( $atts );
$content_img3 = get_theme_mod( 'gallery_img3', get_template_directory_uri() . '/images/gallery.png' );

$img_url4      = get_theme_mod( 'gallery_img4', get_template_directory_uri() . '/images/gallery.jpg' );
$section_atts = travelagency_get_html_atts( $atts );
$content_img4 = get_theme_mod( 'gallery_img4', get_template_directory_uri() . '/images/gallery.png' );

$img_url5      = get_theme_mod( 'gallery_img5', get_template_directory_uri() . '/images/gallery.jpg' );
$section_atts = travelagency_get_html_atts( $atts );
$content_img5 = get_theme_mod( 'gallery_img5', get_template_directory_uri() . '/images/gallery.png' );

$img_url6      = get_theme_mod( 'gallery_img6', get_template_directory_uri() . '/images/gallery.jpg' );
$section_atts = travelagency_get_html_atts( $atts );
$content_img6 = get_theme_mod( 'gallery_img6', get_template_directory_uri() . '/images/gallery.png' );

$img_url7      = get_theme_mod( 'gallery_img7', get_template_directory_uri() . '/images/gallery.jpg' );
$section_atts = travelagency_get_html_atts( $atts );
$content_img7 = get_theme_mod( 'gallery_img7', get_template_directory_uri() . '/images/gallery.png' );

$img_url8      = get_theme_mod( 'gallery_img8', get_template_directory_uri() . '/images/gallery.jpg' );
$section_atts = travelagency_get_html_atts( $atts );
$content_img8 = get_theme_mod( 'gallery_img8', get_template_directory_uri() . '/images/gallery.png' );




$insta_usr = get_theme_mod( 'gallery_insta_usr' );
$imgs_num  = absint( get_theme_mod( 'gallery_imgs_num', 6 ) );
$imgs_col  = absint( get_theme_mod( 'gallery_imgs_col', 6 ) );

$imgs_num = ( $imgs_num >= 4 && $imgs_num <= 12 ) ? $imgs_num : 6;
$imgs_col = ( $imgs_num >= 4 && $imgs_num <= 8 ) ? $imgs_num : 6;
?>
<section <?php echo $section_atts; ?>>
    <div class="container wide-container section-inner">
        <?php
            if ( $title || $desc )
            {
                echo '<div class="section-header section-header-style-none">';
                if ( $title )
                {
                    printf( '<h2 class="section-title">%s</h2>', wp_kses( $title, travelagency_global_kses( 'inline' ) ) );
                }
            }
		?>
		<div class="show-client">
			<?php
                if ( $content_img )
                {
                    echo '<div class="section-thumbnail">';
                    printf( '<img src="%s" alt="hero-section-thumbnail" />', esc_url( $content_img ) );
                    echo '</div>';
                }			
                if ( $content_img2 )
                {
                    echo '<div class="section-thumbnail">';
                    printf( '<img src="%s" alt="hero-section-thumbnail" />', esc_url( $content_img2 ) );
                    echo '</div>';
                }				
                if ( $content_img3 )
                {
                    echo '<div class="section-thumbnail">';
                    printf( '<img src="%s" alt="hero-section-thumbnail" />', esc_url( $content_img3 ) );
                    echo '</div>';
                }		
                if ( $content_img4 )
                {
                    echo '<div class="section-thumbnail">';
                    printf( '<img src="%s" alt="hero-section-thumbnail" />', esc_url( $content_img4 ) );
                    echo '</div>';
                }		
                if ( $content_img5 )
                {
                    echo '<div class="section-thumbnail">';
                    printf( '<img src="%s" alt="hero-section-thumbnail" />', esc_url( $content_img5 ) );
                    echo '</div>';
                }	
                if ( $content_img6 )
                {
                    echo '<div class="section-thumbnail">';
                    printf( '<img src="%s" alt="hero-section-thumbnail" />', esc_url( $content_img6 ) );
                    echo '</div>';
                }	
                if ( $content_img7 )
                {
                    echo '<div class="section-thumbnail">';
                    printf( '<img src="%s" alt="hero-section-thumbnail" />', esc_url( $content_img7 ) );
                    echo '</div>';
                }	
                if ( $content_img8 )
                {
                    echo '<div class="section-thumbnail">';
                    printf( '<img src="%s" alt="hero-section-thumbnail" />', esc_url( $content_img8 ) );
                    echo '</div>';
                }	
	
			?>
		</div>


    </div>
</section>