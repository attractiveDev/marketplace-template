<?php
/**
 * Call to action section for the frontpage
 *
 * @package marketingfirm
 */

if ( get_theme_mod( 'cta_off', false ) )
{
    return;
}

$sid  = get_theme_mod( 'cta_id', 'cta' );
$sid  = travelagency_is_valid_css_id_class( $sid ) ? trim( $sid ) : '';
$atts = array(
    'id'    => $sid,
    'class' => array(
        'section',
        'cta-section'
    ),
    'data-eltype' => 'frontpagesection',
    'style'       => array()
);
$section_atts = travelagency_get_html_atts( $atts );

$title = get_theme_mod( 'cta_title', esc_html__( 'What are you waiting for?', 'marketingfirm' ) );
$desc  = get_theme_mod( 'cta_desc', esc_html__( 'Get started now, go to your favourite Destination', 'marketingfirm' ) );

$btn_title  = get_theme_mod( 'cta_btn_title', esc_html__( 'Lets Talk Now!', 'marketingfirm' ) );
$btn_link   = get_theme_mod( 'cta_btn_link', '#' );
$btn_target = (bool) get_theme_mod( 'cta_btn_target' );

?>
<section <?php echo $section_atts; ?>>
    <div class="container wide-container section-inner">
        <div class="cta-box">
            <?php 
                if ( $title || $desc )
                {
                    echo '<div class="cta-box-info"><div class="cta-box-info-body">';
                    if ( $title )
                    {
                        printf( '<h2 class="cta-box-title">%s</h2>', wp_kses( $title, travelagency_global_kses( 'inline' ) ) );
                    }
                    if ( $desc )
                    {
                        printf( '<div class="cta-box-desc">%s</div>', wpautop( $desc ) );
                    }
                    echo '</div></div>';
                }

                if ( $btn_title && $btn_link )
                {
                    echo '<div class="cta-box-actions">';
                    printf(
                        '<a href="%1$s" class="button cta-box-action-link"%2$s>%3$s</a>',
                        esc_url( $btn_link ),
                        $btn_target ? ' target="_blank"' : ' target="_self"',
                        esc_html( $btn_title )
                    );
                    echo '</div>';
                }
            ?>
        </div>
    </div>
</section>