<?php
/**
 * Blog section for the frontpage
 *
 * @package marketingfirm
 */

if ( get_theme_mod( 'blog_off', false ) )
{
    return;
}

$sid  = get_theme_mod( 'blog_id', 'blog' );
$sid  = travelagency_is_valid_css_id_class( $sid ) ? trim( $sid ) : '';
$atts = array(
    'id'    => $sid,
    'class' => array(
        'section',
        'blog-section'
    ),
    'data-eltype' => 'frontpagesection',
    'style'       => array()
);
//$img_url = get_theme_mod( 'blog_img', get_template_directory_uri() . '/images/blog.jpg' );
//if ( $img_url )
//{
 //   $atts['style'][] = 'background-image:url(' . esc_url( $img_url ) . ')';
//}
$section_atts = travelagency_get_html_atts( $atts );

$title = get_theme_mod( 'blog_title', esc_html__( 'Read Blog', 'marketingfirm' ) );
//$desc  = get_theme_mod( 'blog_desc', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis neque velit, non vehicula eros hendrerit vitae.' );
$posts_num = absint( get_theme_mod( 'blog_posts_num', 3 ) );
$posts_col = absint( get_theme_mod( 'blog_posts_col', 3 ) );
if ( $posts_col <= 1 || $posts_col > 4 )
{
    $posts_col = 3;
}

$posts_query = new WP_Query( array(
    'post_status'         => 'publish',
    'posts_per_page'      => $posts_num,
    'ignore_sticky_posts' => true
) );
?>
<section <?php echo $section_atts; ?>>
    <div class="container wide-container section-inner">
        <?php 
            if ( $title || $desc )
            {
                echo '<div class="section-header section-header-style-2">';
                if ( $title )
                {
                    printf( '<h2 class="section-title">%s</h2>', wp_kses( $title, travelagency_global_kses( 'inline' ) ) );
                }
                if ( $desc )
                {
                    printf( '<div class="section-desc">%s</div>', wpautop( $desc ) );
                }
                echo '</div>';
            }

            if ( $posts_query->have_posts() )
            {
                printf( '<div class="row blog-post-entries blog-post-entries-%scols">', $posts_col );
                $col_classes = 'blog-post-entry-col';
                switch ( $posts_col )
                {
                    case 2:
                        $col_classes .= ' col-md-6';
                        break;

                    case 3:
                        $col_classes .= ' col-md-6 col-xl-4';
                        break;

                    case 4:
                        $col_classes .= ' col-md-6 col-xl-3';
                        break;
                    
                    default:
                        break;
                }
                while ( $posts_query->have_posts() )
                {
                    $posts_query->the_post();
                    echo '<div class="' . esc_attr( $col_classes ) . '">';
                    get_template_part( 'template-parts/loop-mini-grid' );
                    echo '</div>';
                }

                echo '</div>';
            }
        ?>
    </div>
</section>